[[Reg-AduMOC/CAPÍTULO VII DA RESTITUIÇÃO E DA COMPENSAÇÃO]]

# SEÇÃO II DA COMPENSAÇÃO

Art. 113. O importador que apurar crédito relativo ao
imposto, passível de restituição ou de ressarcimento, poderá

(Pós-Edital)    854

utilizá-lo na compensação de débitos próprios relativos a
quaisquer tributos e contribuições administrados pela
Secretaria da Receita Federal do Brasil (Lei nº 9.430, de 1996,
art. 74, caput, com a redação dada pela Lei nº 10.637, de
2002, art. 49).

§ 1º O crédito apurado pelo importador, nos termos do
caput, não poderá ser utilizado para compensar crédito
tributário, relativo a tributos ou contribuições, devido no
momento do registro da declaração de importação (Lei nº
9.430, de 1996, art. 74, § 3º, inciso II, com a redação dada
pela Lei nº 10.637, de 2002, art. 49).

§ 2º A Secretaria da Receita Federal do Brasil disciplinará o
disposto neste artigo (Lei nº 9.430, de 1996, art. 74, § 14,
com a redação dada pela Lei nº 11.051, de 29 de dezembro
de 2004, art. 4º).