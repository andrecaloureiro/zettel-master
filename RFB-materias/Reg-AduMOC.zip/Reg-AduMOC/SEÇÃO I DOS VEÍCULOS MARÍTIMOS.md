[[Reg-AduMOC/CAPÍTULO III DAS NORMAS ESPECÍFICAS]]

# SEÇÃO I DOS VEÍCULOS MARÍTIMOS

Art. 54. Os transportadores, bem como os agentes
autorizados de embarcações procedentes do exterior,
deverão [[informar à autoridade aduaneira dos portos de atracação]], na forma e com a antecedência mínima
estabelecidas pela Secretaria da Receita Federal do Brasil, a
hora estimada de sua chegada, a sua procedência, o seu
destino e, se for o caso, a quantidade de passageiros.

Art. 55. O responsável pelo veículo deverá apresentar, além
dos documentos exigidos no art. 42, as [[declarações de bagagens dos viajantes]], se exigidas pelas normas específicas,
e a lista dos [[pertences da tripulação]], como tais entendidos
os bens e objetos de uso pessoal componentes de sua
bagagem.

Parágrafo único. Nos portos seguintes ao primeiro de
entrada, será ainda exigido o [[passe de saída]] do porto da
escala anterior.