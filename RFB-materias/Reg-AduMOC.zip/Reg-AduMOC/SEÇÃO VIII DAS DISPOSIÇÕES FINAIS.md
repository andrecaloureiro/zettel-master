[[Reg-AduMOC/CAPÍTULO II DO TRÂNSITO ADUANEIRO]]

# SEÇÃO VIII DAS DISPOSIÇÕES FINAIS

Art. 350. A mercadoria em trânsito aduaneiro lançada ao
território aduaneiro por motivo de segurança ou
arremessada por motivo de acidente do veículo
transportador deverá ser encaminhada por quem a
encontrou à unidade da Secretaria da Receita Federal do
Brasil mais próxima.

Art. 351. As disposições do presente Capítulo aplicam-se ao
trânsito aduaneiro decorrente de acordos ou convênios
internacionais, desde que não os contrariem.

Art. 352. As disposições deste Capítulo não se aplicam às
remessas postais internacionais, as quais estão sujeitas a
normas próprias.