[[Reg-AduMOC/CAPÍTULO VII DA SUSPENSÃO DO PAGAMENTO]]

# SEÇÃO I DAS DISPOSIÇÕES PRELIMINARES

Art. 260. As normas relativas à suspensão do pagamento do
imposto de importação ou do imposto sobre produtos
industrializados vinculado à importação, referentes aos
regimes aduaneiros especiais, aplicam-se também à
contribuição para o PIS/PASEP-Importação e à COFINS-
Importação (Lei nº 10.865, de 2004, art. 14, caput).
