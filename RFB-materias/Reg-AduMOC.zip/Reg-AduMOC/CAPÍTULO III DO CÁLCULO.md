[[Reg-AduMOC/TÍTULO I DO IMPOSTO SOBRE PRODUTOS INDUSTRIALIZADOS]]

# CAPÍTULO III DO CÁLCULO

Art. 240. O imposto será calculado mediante aplicação das
alíquotas, constantes da Tabela de Incidência do Imposto
sobre Produtos Industrializados, sobre a base de cálculo de
que trata o art. 239 (Lei nº 4.502, de 1964, art. 13).
Parágrafo único. Na hipótese do art. 98, a alíquota para o
cálculo do imposto será de cinqüenta por cento (Lei nº
10.833, de 2003, art. 67, caput).