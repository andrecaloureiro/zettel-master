[[Reg-AduMOC/CAPÍTULO X DA EXPORTAÇÃO TEMPORÁRIA PARA APERFEIÇOAMENTO PASSIVO]]

# SEÇÃO IV DAS DISPOSIÇÕES FINAIS

Art. 457. Aplicam-se ao regime, no que couber, as normas
previstas para o regime de exportação temporária.[[Reg-AduMOC/CAPÍTULO XII DO REGIME ADUANEIRO ESPECIAL DE IMPORTAÇÃO DE PETRÓLEO BRUTO E SEUS DERIVADOS - REPEX]]

# SEÇÃO IV DAS DISPOSIÇÕES FINAIS

Art. 469. O controle aduaneiro da entrada e da saída do País
de produto admitido no regime será efetuado mediante
processo informatizado.

Art. 470. A Secretaria da Receita Federal do Brasil poderá, no
âmbito de sua competência, editar atos normativos para a
implementação do disposto neste Capítulo.