[[Reg-AduMOC/SEÇÃO VI DOS TERMOS, LIMITES E CONDIÇÕES]]

# SUBSEÇÃO IX DOS BENS ADQUIRIDOS EM LOJA FRANCA

Art. 169. A isenção do imposto na aquisição de mercadorias
em loja franca instalada no País, a que se refere a alínea "e"
do inciso II do art. 136, será aplicada com observância do
disposto nos arts. 476 a 479 e dos termos, limites e
condições estabelecidos pelo Ministro de Estado da Fazenda
(Decreto-Lei nº 2.120, de 1984, art. 1º, § 2º, alínea "a"; Lei
nº 8.032, de 1990, art. 2º, inciso II, alínea "e"; e Lei nº 8.402,
de 1992, art. 1º, inciso IV).