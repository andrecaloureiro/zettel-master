[[Reg-AduMOC/TÍTULO II DAS NORMAS ESPECIAIS]]

# CAPÍTULO IV DAS MERCADORIAS PRESUMIDAS IDÊNTICAS

Art. 667. As mercadorias descritas de forma semelhante em
diferentes declarações aduaneiras do mesmo contribuinte,
salvo prova em contrário, são presumidas idênticas para fins
de determinação do tratamento tributário ou aduaneiro (Lei
nº 10.833, de 2003, art. 68, caput).

Parágrafo único. Para efeito do disposto no caput, a
identificação das mercadorias poderá ser realizada, no curso
do despacho aduaneiro ou em outro momento, com base em
documentos, inclusive obtidos junto a clientes ou
fornecedores, ou no processo produtivo em que tenham sido
ou venham a ser utilizadas (Lei nº 10.833, de 2003, art. 68,
parágrafo único).