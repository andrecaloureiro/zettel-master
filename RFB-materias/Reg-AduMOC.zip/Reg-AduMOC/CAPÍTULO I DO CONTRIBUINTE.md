[[Reg-AduMOC/TÍTULO III DA CONTRIBUIÇÃO PARA O PISPASEP E DA COFINS, NA IMPORTAÇÃO DE CIGARRO]]

# CAPÍTULO I DO CONTRIBUINTE

Art. 293. O importador de cigarros classificados no código
2402.20.00 da Nomenclatura Comum do Mercosul sujeita-
se, na condição de contribuinte, e de contribuinte substituto
dos comerciantes varejistas, ao pagamento da contribuição
para o PIS/PASEP e da COFINS (Lei nº 9. 532, de 1997, art.
53).