[[Reg-AduMOC/SEÇÃO I DA ADMISSÃO TEMPORÁRIA COM SUSPENSÃO TOTAL DO PAGAMENTO DE TRIBUTOS]]

# SUBSEÇÃO IV DA GARANTIA

Art. 364. Será exigida garantia das obrigações fiscais
constituídas no termo de responsabilidade, na forma do art.
759. (Redação dada pelo Decreto nº 8.010, de 2013)

Parágrafo único. A Secretaria da Receita Federal do Brasil
disporá sobre os casos em que poderá ser dispensada a
garantia a que se refere o caput (Decreto-Lei nº 37, de 1966,
art. 75, § 4º, com a redação dada pela Lei nº 12.350, de 2010,
art. 40). (Incluído pelo Decreto nº 8.010, de 2013)

Art. 365. Quando os bens admitidos no regime forem
danificados, em virtude de sinistro, o valor da garantia será,
a pedido do interessado, reduzido proporcionalmente ao
montante do prejuízo.

§ 1º Não caberá a redução quando ficar provado que o
sinistro:

I - ocorreu por culpa ou dolo do beneficiário do regime; ou

II - resultou de o bem haver sido utilizado em finalidade
diferente daquela que tenha justificado a concessão do
regime.

§ 2º Para habilitar-se à redução do valor da garantia, o
interessado apresentará laudo pericial do órgão oficial
competente, do qual deverão constar as causas e os efeitos
do sinistro.

Art. 366. No caso de comprovação da reexportação
parcelada dos bens, será concedida, a pedido do
interessado, a correspondente redução do valor da garantia.