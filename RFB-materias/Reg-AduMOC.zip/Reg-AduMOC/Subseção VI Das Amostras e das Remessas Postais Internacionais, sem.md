[[Reg-AduMOC/SEÇÃO VI DOS TERMOS, LIMITES E CONDIÇÕES]]

# Subseção VI Das Amostras e das Remessas Postais Internacionais, sem
Valor Comercial

Art. 153. Consideram-se sem valor comercial, para os efeitos
da alínea "b" do inciso II do art. 136:

I - as amostras representadas por quantidade, fragmentos ou
partes de qualquer mercadoria, estritamente necessários
para dar a conhecer sua natureza, espécie e qualidade; e

II - os bens contidos em remessas postais internacionais
consideradas sem valor comercial, que não se prestem à
utilização com fins lucrativos e cujo valor Free On Board -
FOB não exceda a US$ 10,00 (dez dólares dos Estados Unidos
da América).