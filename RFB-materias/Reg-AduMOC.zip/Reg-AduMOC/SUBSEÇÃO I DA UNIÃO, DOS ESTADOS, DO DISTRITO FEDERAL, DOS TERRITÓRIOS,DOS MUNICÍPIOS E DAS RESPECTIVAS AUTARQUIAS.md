[[Reg-AduMOC/SEÇÃO VI DOS TERMOS, LIMITES E CONDIÇÕES]]

# SUBSEÇÃO I DA UNIÃO, DOS ESTADOS, DO DISTRITO FEDERAL, DOS TERRITÓRIOS,DOS MUNICÍPIOS E DAS RESPECTIVAS AUTARQUIAS

Art. 139. A isenção às importações realizadas pela União,
pelos Estados, pelo Distrito Federal, pelos Territórios e pelos
Municípios aplica-se a:

I - equipamentos, máquinas, aparelhos ou instrumentos,
destinados a obras de construção, ampliação, exploração e
conservação de serviços públicos operados direta ou
indiretamente pelos titulares do benefício;

II - partes, peças, acessórios, ferramentas e utensílios que,
em quantidade normal, acompanhem os bens de que trata o
inciso I ou que se destinem a reparo ou a manutenção do
equipamento, máquina, aparelho ou instrumento de
procedência estrangeira instalado no País; e

III - bens de consumo, quando direta e estritamente
relacionados com a atividade dos beneficiários e desde que
necessários a complementar a oferta do similar nacional.

Art. 140. A isenção às importações realizadas pelas
autarquias somente se aplica aos bens referidos no inciso III
do art. 139, observadas as condições ali estabelecidas.