[[Reg-AduMOC/CAPÍTULO III DAS ATIVIDADES RELACIONADAS AOS SERVIÇOS ADUANEIROS]]

# SEÇÃO III DAS ATIVIDADES DE UNITIZAÇÃO E DE DESUNITIZAÇÃO DE CARGA

Art. 812. A unitização e a desunitização de cargas, quando
realizadas em locais e recintos alfandegados, serão feitas
somente por agentes previamente credenciados pela
Secretaria da Receita Federal do Brasil.

Parágrafo único. A Secretaria da Receita Federal do Brasil
estabelecerá os termos, requisitos e condições para o
credenciamento dos agentes referidos no caput.