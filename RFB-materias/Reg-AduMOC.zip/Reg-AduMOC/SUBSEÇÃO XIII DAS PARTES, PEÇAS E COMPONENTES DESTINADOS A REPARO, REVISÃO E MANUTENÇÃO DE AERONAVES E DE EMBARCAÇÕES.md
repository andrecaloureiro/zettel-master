[[Reg-AduMOC/SEÇÃO VI DOS TERMOS, LIMITES E CONDIÇÕES]]

# SUBSEÇÃO XIII DAS PARTES, PEÇAS E COMPONENTES DESTINADOS A REPARO, REVISÃO E MANUTENÇÃO DE AERONAVES E DE EMBARCAÇÕES

Art. 174. A isenção do imposto, na importação de partes,
peças e componentes, será reconhecida aos bens destinados
a reparo, revisão ou manutenção de aeronaves e de
embarcações. (Redação dada pelo Decreto nº 7.044, de
2009).

§ 1º Para cumprimento do disposto no caput, o importador
deverá fazer prova da posse ou propriedade da aeronave ou
embarcação. (Incluído pelo Decreto nº 7.044, de 2009).

§ 2º Na hipótese de a importação ser promovida por oficina
especializada em reparo, revisão ou manutenção de
aeronaves, esta deverá: (Incluído pelo Decreto nº 7.044, de
2009).

I - apresentar contrato de prestação de serviços, indicando o
proprietário ou possuidor da aeronave; e (Incluído pelo
Decreto nº 7.044, de 2009).

II - estar homologada pelo órgão competente do Ministério
da Defesa. (Incluído pelo Decreto nº 7.044, de 2009).