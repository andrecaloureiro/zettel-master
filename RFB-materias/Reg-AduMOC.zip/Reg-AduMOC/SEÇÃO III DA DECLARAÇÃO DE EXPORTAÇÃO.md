[[Reg-AduMOC/CAPÍTULO II DO DESPACHO DE EXPORTAÇÃO]]

# SEÇÃO III DA DECLARAÇÃO DE EXPORTAÇÃO

Art. 586. O documento base do despacho de exportação é a
declaração de exportação.

Parágrafo único. A Secretaria da Receita Federal do Brasil
poderá estabelecer diferentes tipos e formas de
apresentação da declaração de exportação, apropriados à
natureza dos despachos, ou a situações específicas em
relação à mercadoria ou a seu tratamento tributário.

Art. 587. A retificação da declaração de exportação,
mediante alteração das informações prestadas, ou a inclusão
de outras, será feita pela autoridade aduaneira, de ofício ou
a requerimento do exportador, na forma estabelecida pela
Secretaria da Receita Federal do Brasil.