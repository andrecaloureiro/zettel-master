[[Reg-AduMOC/CAPÍTULO I DAS NORMAS GERAIS]]

# SEÇÃO V DAS UNIDADES DE CARGA

Art. 39. É livre, no País, a entrada e a saída de unidades de
carga e seus acessórios e equipamentos, de qualquer
nacionalidade, bem como a sua utilização no transporte
doméstico (Lei no 9.611, de 19 de fevereiro de 1998, art. 26).

§ 1º Aplica-se automaticamente o [[regime de admissão temporária ou de exportação temporária]] aos bens referidos
no caput.

§ 2º Poderá ser exigida a prestação de informações para fins
de controle aduaneiro sobre os bens referidos no caput, nos
termos estabelecidos em ato normativo da Secretaria da
Receita Federal do Brasil.

(Pós-Edital)    844

§ 3º Entende-se por unidade de carga, para os efeitos deste
artigo, qualquer [[equipamento adequado à unitização de mercadorias]] a serem transportadas, sujeitas a
movimentação de forma [[indivisível]] (Lei nº 9.611, 1998, art.
24, caput).