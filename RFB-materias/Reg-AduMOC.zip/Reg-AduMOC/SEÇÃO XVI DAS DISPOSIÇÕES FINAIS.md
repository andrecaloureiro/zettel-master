[[Reg-AduMOC/CAPÍTULO III DOS CASOS ESPECIAIS]]

# SEÇÃO XVI DAS DISPOSIÇÕES FINAIS

Art. 637. A Secretaria da Receita Federal do Brasil poderá
estabelecer, em ato normativo específico, a obrigatoriedade
do registro especial a que se refere o parágrafo único do art.
599 na importação de outros produtos (Decreto-Lei nº 1.593,
de 1977, art. 1º, § 6º, com a redação dada pela Medida
Provisória no 2.158-35, de 2001, art. 32).