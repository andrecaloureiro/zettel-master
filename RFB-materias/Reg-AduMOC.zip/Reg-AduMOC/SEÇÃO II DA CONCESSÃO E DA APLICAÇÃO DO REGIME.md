[[Reg-AduMOC/CAPÍTULO XVIII DO DEPÓSITO FRANCO]]

# SEÇÃO II DA CONCESSÃO E DA APLICAÇÃO DO REGIME

Art. 500. O regime de depósito franco será concedido
somente quando autorizado em acordo ou convênio
internacional firmado pelo Brasil.
Art. 501. Será obrigatória a verificação da mercadoria
admitida no regime:
I - cuja permanência no recinto ultrapasse o prazo
estabelecido pela Secretaria da Receita Federal do Brasil; ou
II - quando houver fundada suspeita de falsa declaração de
conteúdo.
Art. 502. Aplicam-se às mercadorias admitidas no regime de
depósito franco as vedações estabelecidas no art. 327.
Art. 503. A Secretaria da Receita Federal do Brasil poderá, no
âmbito de sua competência, editar atos normativos para a
implementação do disposto nesta Seção.