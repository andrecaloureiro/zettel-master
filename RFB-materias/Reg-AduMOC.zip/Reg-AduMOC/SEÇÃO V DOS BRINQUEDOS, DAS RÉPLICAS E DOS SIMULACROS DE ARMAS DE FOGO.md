[[Reg-AduMOC/CAPÍTULO III DOS CASOS ESPECIAIS]]

# SEÇÃO V DOS BRINQUEDOS, DAS RÉPLICAS E DOS SIMULACROS DE ARMAS DE FOGO

Art. 611. É vedada a importação de brinquedos, réplicas e
simulacros de armas de fogo, que com estas se possam
confundir (Lei no 10.826, de 22 de dezembro de 2003, art.
26, caput).

Parágrafo único. Excetuam-se da proibição referida no caput
as réplicas e os simulacros destinados à instrução, ao
adestramento, ou à coleção de usuário autorizado, nas
condições fixadas pelo Comando do Exército (Lei nº 10.826,
de 2003, art. 26, parágrafo único).

(Pós-Edital)    926