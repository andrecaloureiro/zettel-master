[[Reg-AduMOC/CAPÍTULO III DA DECADÊNCIA E DA PRESCRIÇÃO]]

# SEÇÃO II DA PRESCRIÇÃO

Art. 755. O direito de ação para cobrança do crédito
tributário prescreve em cinco anos, contados da data de sua
constituição definitiva (Decreto-Lei nº 37, de 1966, art. 140,
com a redação dada pelo Decreto-Lei no 2.472, de 1988, art.
4º; e Lei nº 5.172, de 1966, art. 174, caput).

Parágrafo único. A prescrição dos créditos tributários pode
ser reconhecida de ofício pela autoridade aduaneira (Lei no
11.941, de 2009, art. 53). (Incluído pelo Decreto nº 7.213, de
2010).

Art. 756. O prazo a que se refere o art. 755 não corre
(Decreto-Lei nº 37, de 1966, art. 141, com a redação dada
pelo Decreto-Lei no 2.472, de 1988, art. 4º):

I - enquanto o processo de cobrança depender de exigência
a ser satisfeita pelo contribuinte; ou

II - até que a autoridade aduaneira seja diretamente
informada pela autoridade judiciária ou órgão do Ministério
Público, da revogação de ordem ou decisão judicial que haja
suspendido, anulado ou modificado a exigência, inclusive no
caso de sobrestamento do processo.

Art. 757. Prescreve em dois anos a ação anulatória da
decisão administrativa que denegar a restituição de tributo
(Lei nº 5.172, de 1966, art. 169, caput).