[[Reg-AduMOC/TÍTULO III DA CONTRIBUIÇÃO PARA O PISPASEP E DA COFINS, NA IMPORTAÇÃO DE CIGARRO]]

# CAPÍTULO II DO CÁLCULO E DO PAGAMENTO

Art. 294. O cálculo das contribuições será efetuado com
observância das mesmas normas aplicáveis aos fabricantes
de cigarros nacionais (Lei nº 9.532, de 1997, art. 53).

Art. 295. O pagamento das contribuições deverá ser
efetuado na data do registro da declaração de importação
no SISCOMEX (Lei nº 9.532, de 1997, art. 54).