[[Reg-AduMOC/TÍTULO I DO IMPOSTO DE IMPORTAÇÃO]]

# CAPÍTULO IX DA IMUNIDADE DOS LIVROS, JORNAIS E PERIÓDICOS E DO PAPEL DESTINADO A SUA IMPRESSÃO

(Incluído pelo Decreto nº 7.213, de 2010).

Art. 211-A. É concedida imunidade do imposto de
importação às importações de livros, jornais e periódicos e
do papel destinado a sua impressão (Constituição, art. 150,
inciso VI, alínea "d"). (Incluído pelo Decreto nº 7.213, de
2010).

Art. 211-B. Deve manter registro especial na Secretaria da
Receita Federal do Brasil a pessoa jurídica que (Lei no 11.945,
de 2009, art. 1º, caput): (Incluído pelo Decreto nº 7.213, de
2010).

I - exercer as atividades de comercialização e importação de
papel destinado à impressão de livros, jornais e periódicos, a
que se refere o art. 211-A; e (Incluído pelo Decreto nº 7.213,
de 2010).

II - adquirir o papel a que se refere o art. 211-A para a
utilização na impressão de livros, jornais e periódicos.
(Incluído pelo Decreto nº 7.213, de 2010).

§ 1º A transferência do papel a detentores do registro
especial de que trata o caput faz prova da regularidade da
sua destinação, sem prejuízo da responsabilidade, pelos
tributos devidos, da pessoa jurídica que, tendo adquirido o
papel beneficiado com imunidade, desviar sua finalidade
constitucional (Lei no 11.945, de 2009, art. 1º, § 1º). (Incluído
pelo Decreto nº 7.213, de 2010).

§ 2º Compete à Secretaria da Receita Federal do Brasil (Lei
no 11.945, de 2009, art. 1º, § 3º): (Incluído pelo Decreto nº
7.213, de 2010).

I - expedir normas complementares relativas ao registro
especial e ao cumprimento das exigências a que estão
sujeitas as pessoas jurídicas para sua concessão; e (Incluído
pelo Decreto nº 7.213, de 2010).

II - estabelecer a periodicidade e a forma de comprovação da
correta destinação do papel beneficiado com imunidade,
inclusive mediante a instituição de obrigação acessória
destinada ao controle da sua comercialização e importação.
(Incluído pelo Decreto nº 7.213, de 2010).