[[Reg-AduMOC/CAPÍTULO V DAS ISENÇÕES DO IMPOSTO]]

# SEÇÃO III DA BAGAGEM

Art. 224. Os bens integrantes de bagagem, acompanhada ou
desacompanhada, de viajante que se destine ao exterior
estão isentos do imposto (Regime Aduaneiro de Bagagem no
Mercosul, Artigo 15, inciso 1, aprovado pela Decisão CMC no
53, de 2008, internalizada pelo Decreto no 6.870, de 2009).
(Redação dada pelo Decreto nº 7.213, de 2010).

Art. 225. Será dado o tratamento de bagagem a outros bens
adquiridos no País, levados pessoalmente pelo viajante para
o exterior, até o limite de US$ 2.000,00 (dois mil dólares dos
Estados Unidos da América) ou o equivalente em outra
moeda, sempre que se tratarem de mercadorias de livre
exportação e for apresentado documento fiscal
correspondente a sua aquisição (Regime Aduaneiro de
Bagagem no Mercosul, Artigo 15, inciso 2, aprovado pela
Decisão CMC no 53, de 2008, internalizada pelo Decreto no
6.870, de 2009). (Redação dada pelo Decreto nº 7.213, de
2010).

Art. 226. Aplicam-se a esta Seção, no que couber, as normas
previstas para a bagagem na importação.

(Pós-Edital)    872