[[Reg-AduMOC/CAPÍTULO II DAS PENALIDADES]]

# SEÇÃO I DAS ESPÉCIES DE PENALIDADES

Art. 675. As infrações estão sujeitas às seguintes
penalidades, aplicáveis separada ou cumulativamente
(Decreto-Lei nº 37, de 1966, art. 96; Decreto-Lei nº 1.455, de
1976, arts. 23, § 1º, com a redação dada pela Lei nº 10.637,
de 2002, art. 59, e 24; Lei no 9.069, de 1995, art. 65, § 3º; e
Lei nº 10.833, de 2003, art. 76):

I - [[perdimento]] do veículo;

II - perdimento da mercadoria;

III - perdimento de moeda;

IV - [[multa]]; e

V - [[sanção administrativa]] .