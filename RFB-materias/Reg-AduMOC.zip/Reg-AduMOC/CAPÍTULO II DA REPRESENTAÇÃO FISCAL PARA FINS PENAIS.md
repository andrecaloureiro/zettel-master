[[Reg-AduMOC/TÍTULO V DAS DISPOSIÇÕES FINAIS]]

# CAPÍTULO II DA REPRESENTAÇÃO FISCAL PARA FINS PENAIS

Art. 740. Sempre que o Auditor-Fiscal da Receita Federal do
Brasil constatar, no exercício de suas atribuições, [[fato que configure, em tese, crime]] contra a ordem tributária, crime
de contrabando ou de descaminho, ou crimes em
detrimento da Fazenda Nacional ou contra a administração
pública federal, deverá efetuar a correspondente
representação fiscal para fins penais, a ser [[encaminhada ao Ministério Público]], na forma estabelecida pela Secretaria da
Receita Federal do Brasil.

Art. 741. A representação fiscal para fins penais relativa aos
crimes contra a ordem tributária será encaminhada ao
Ministério Público após ter sido [[proferida a decisão final administrativa]], no processo fiscal (Lei nº 9.430, de 1996, art.
83, caput com a redação dada pela Lei nº 12.350, de 2010,
art. 43). (Redação dada pelo Decreto nº 8.010, de 2013)

Parágrafo único. Na hipótese de [[concessão de parcelamento]]
do crédito tributário, a representação fiscal para fins penais
somente será encaminhada ao Ministério Público após a
exclusão da pessoa física ou jurídica do parcelamento (Lei nº
9.430, de 1996, art. 83, § 1º, com a redação dada pela Lei nº
12.382, de 2011, art. 6º). (Incluído pelo Decreto nº 8.010, de
2013)