[[Reg-AduMOC/SEÇÃO VI DOS TERMOS, LIMITES E CONDIÇÕES]]

# SUBSEÇÃO XVI DOS BENS IMPORTADOS PELA ZONA FRANCA DE MANAUS E PELA AMAZÔNIA OCIDENTAL

Art. 177. A entrada de mercadorias estrangeiras com isenção
do imposto, na Zona Franca de Manaus e na Amazônia
Ocidental, será feita com observância do disposto nos arts.
504 e 516, respectivamente.