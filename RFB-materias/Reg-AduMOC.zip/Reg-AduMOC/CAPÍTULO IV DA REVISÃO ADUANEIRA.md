[[Reg-AduMOC/TÍTULO I DO DESPACHO ADUANEIRO]]

# CAPÍTULO IV DA REVISÃO ADUANEIRA

Art. 638. Revisão aduaneira é o ato pelo qual é apurada, após
o desembaraço aduaneiro, a regularidade do pagamento dos
impostos e dos demais gravames devidos à Fazenda
Nacional, da aplicação de benefício fiscal e da exatidão das
informações prestadas pelo importador na declaração de
importação, ou pelo exportador na declaração de
exportação (Decreto-Lei nº 37, de 1966, art. 54, com a
redação dada pelo Decreto-Lei no 2.472, de 1988, art. 2º; e
Decreto-Lei nº 1.578, de 1977, art. 8º).

§ 1º Para a constituição do crédito tributário, apurado na
revisão, a autoridade aduaneira deverá observar os prazos
referidos nos arts. 752 e 753.

§ 2º A revisão aduaneira deverá estar concluída no prazo de
cinco anos, contados da data:

I - do registro da declaração de importação correspondente
(Decreto-Lei nº 37, de 1966, art. 54, com a redação dada pelo
Decreto-Lei no 2.472, de 1988, art. 2º); e

II - do registro de exportação.

§ 3º Considera-se concluída a revisão aduaneira na data da
ciência, ao interessado, da exigência do crédito tributário
apurado.