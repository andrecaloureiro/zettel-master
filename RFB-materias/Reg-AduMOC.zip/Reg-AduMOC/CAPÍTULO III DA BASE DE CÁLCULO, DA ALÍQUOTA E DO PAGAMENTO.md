[[Reg-AduMOC/TÍTULO IV DA CONTRIBUIÇÃO DE INTERVENÇÃO NO DOMÍNIO ECONÔMICO - COMBUSTÍVEIS]]

# CAPÍTULO III DA BASE DE CÁLCULO, DA ALÍQUOTA E DO PAGAMENTO

Art. 302. A base de cálculo da CIDE-Combustíveis é a unidade
de medida estabelecida para os produtos de que trata o art.
299 (Lei nº 10.336, de 2001, art. 4º).

Art. 303. A CIDE-Combustíveis será calculada pela aplicação
de alíquotas específicas, conforme estabelecido em ato
normativo específico (Lei nº 10.336, de 2001, art. 5º, caput,
com a redação dada pela Lei nº 10.636, de 30 de dezembro
de 2002, art. 14).

Art. 304. O pagamento da CIDE-Combustíveis será efetuado
na data do registro da declaração de importação (Lei nº
10.336, de 2001, art. 6º, caput).