[[Reg-AduMOC/CAPÍTULO II DO DESPACHO DE EXPORTAÇÃO]]

# SEÇÃO VIII DA SIMPLIFICAÇÃO DO DESPACHO

Art. 595. Poderá ser autorizado, em ato normativo da
Secretaria da Receita Federal do Brasil (Decreto-Lei nº 37, de
1966, art. 52, caput, com a redação dada pelo Decreto-Lei no
2.472, de 1988, art. 2º):

I - a adoção de procedimentos para simplificação do
despacho de exportação; e

(Pós-Edital)    924

II - o embarque da mercadoria ou a sua saída do território
aduaneiro antes do registro da declaração de exportação.