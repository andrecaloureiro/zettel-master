[[Reg-AduMOC/CAPÍTULO V DO DRAWBACK]]

# SEÇÃO IV DO DRAWBACK RESTITUIÇÃO

Art. 397. A concessão do regime, na modalidade de
restituição, é de competência da Secretaria da Receita
Federal do Brasil, e poderá abranger, total ou parcialmente,
os tributos pagos na importação de mercadoria exportada
após beneficiamento, ou utilizada na fabricação,
complementação ou acondicionamento de outra exportada.

Parágrafo único. Para usufruir do regime, o interessado
deverá comprovar a exportação de produto em cujo
beneficiamento, fabricação, complementação ou
acondicionamento tenham sido utilizadas as mercadorias
importadas referidas no caput.

Art. 398. A restituição do valor correspondente aos tributos
poderá ser feita mediante crédito fiscal, a ser utilizado em
qualquer importação posterior (Decreto-Lei nº 37, de 1966,
art. 78, § 1º).

Art. 399. Na modalidade de restituição, o regime será
aplicado pela unidade aduaneira que jurisdiciona o
estabelecimento produtor, atendidas as normas
estabelecidas pela Secretaria da Receita Federal do Brasil,
para reconhecimento do direito creditório.