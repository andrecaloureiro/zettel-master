[[Reg-AduMOC/CAPÍTULO III DOS RECINTOS ALFANDEGADOS]]

## SEÇÃO I DAS DISPOSIÇÕES PRELIMINARES

Art. 9º Os recintos alfandegados serão assim declarados pela
autoridade aduaneira competente, na zona primária ou na
zona secundária, a fim de que neles possam ocorrer, sob
controle aduaneiro, movimentação, armazenagem e
despacho aduaneiro de:

I - [[mercadorias procedentes do exterior]], ou a ele destinadas,
inclusive sob regime aduaneiro especial;

II - [[bagagem de viajantes]] procedentes do exterior, ou a ele
destinados; e

III - [[remessas postais internacionais]].

Parágrafo único. Poderão ainda ser alfandegados, em zona
primária, recintos destinados à instalação de [[lojas francas]].

Art. 10. A Secretaria da Receita Federal do Brasil poderá, no
âmbito de sua competência, editar atos normativos para a
implementação do disposto neste Capítulo.

