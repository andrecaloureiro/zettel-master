[[Reg-AduMOC/TÍTULO I DO IMPOSTO SOBRE PRODUTOS INDUSTRIALIZADOS]]

# CAPÍTULO II DA BASE DE CÁLCULO

Art. 239. A base de cálculo do imposto, na importação, é o
valor que servir ou que serviria de base para cálculo do
imposto de importação, por ocasião do despacho aduaneiro,
acrescido do montante desse imposto e dos encargos
cambiais efetivamente pagos pelo importador ou dele
exigíveis (Lei nº 4.502, de 1964, art. 14, inciso I, alínea "b").
§ 1º O disposto no caput não se aplica para o cálculo do
imposto incidente na importação de:
I - produtos sujeitos ao regime de tributação especial
previsto na Lei no 7.798, de 10 de julho de 1989, cuja base
de cálculo será apurada em conformidade com as regras
estabelecidas para o produto nacional; e
II - cigarros classificados no código 2402.20.00 da
Nomenclatura Comum do Mercosul, cuja base de cálculo
será apurada em conformidade com as regras estabelecidas
para o produto nacional (Lei no 9.532, de 1997, art. 52,
caput, com a redação dada pela Lei nº 10.637, de 2002, art.
51).
§ 2º Os produtos referidos nos incisos I e II do § 1º estão
sujeitos ao pagamento do imposto somente por ocasião do
registro da declaração de importação (Lei nº 7.798, de 1989,
art. 4º, alínea "b"; e Lei nº 9.532, de 1997, art. 52, parágrafo
único ).