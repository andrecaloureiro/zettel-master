[[Reg-AduMOC/SEÇÃO VI DOS TERMOS, LIMITES E CONDIÇÕES]]

# SUBSEÇÃO X DO COMÉRCIO DE SUBSISTÊNCIA EM FRONTEIRA

Art. 170. A isenção do imposto na importação de bens
trazidos do exterior, no comércio característico das cidades
situadas nas fronteiras terrestres, aplica-se apenas aos bens
destinados à subsistência da unidade familiar de residentes
nas cidades fronteiriças brasileiras (Decreto-Lei nº 2.120, de
1984, art. 1º, § 2º, alínea "b"; Lei nº 8.032, de 1990, art. 2º,
inciso II, alínea "f"; e Lei nº 8.402, de 1992, art. 1º, inciso IV).

Parágrafo único. Entende-se por bens destinados à
subsistência da unidade familiar, para os efeitos desta
Subseção, os bens estritamente necessários ao uso ou
consumo pessoal e doméstico.