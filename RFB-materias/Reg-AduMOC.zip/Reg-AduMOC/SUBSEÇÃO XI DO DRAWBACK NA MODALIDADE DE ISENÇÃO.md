[[Reg-AduMOC/SEÇÃO VI DOS TERMOS, LIMITES E CONDIÇÕES]]

# SUBSEÇÃO XI DO DRAWBACK NA MODALIDADE DE ISENÇÃO

Art. 171. A isenção do imposto, ao amparo do regime
aduaneiro especial de drawback, será concedida na
importação de mercadorias, em quantidade e qualidade
equivalente à utilizada no beneficiamento, fabricação,
complementação ou acondicionamento de produto
exportado, observado o disposto nos arts. 393 a 396
(Decreto-Lei nº 37, de 1966, art. 78, inciso III).