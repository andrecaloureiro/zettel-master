[[Reg-AduMOC/SEÇÃO II DOS BENEFÍCIOS FISCAIS]]

# SUBSEÇÃO III DOS BENEFÍCIOS FISCAIS NA EXPORTAÇÃO

Art. 515. A exportação de mercadorias da Zona Franca de
Manaus para o exterior, qualquer que seja sua origem, está
isenta do imposto de exportação (Decreto-Lei nº 288, de
1967, art. 5º).