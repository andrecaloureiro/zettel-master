[[Reg-AduMOC/CAPÍTULO II DO DESPACHO DE EXPORTAÇÃO]]

# SEÇÃO IX DAS DISPOSIÇÕES FINAIS

Art. 596. Aplicam-se ao despacho de exportação, no que
couber, as normas estabelecidas para o despacho de
importação (Decreto-Lei nº 1.578, de 1977, art. 8º).