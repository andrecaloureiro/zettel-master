[[Reg-AduMOC/TÍTULO III DO CONTROLE ADMINISTRATIVO ESPECÍFICO]]

# CAPÍTULO IV DO FUNDO ESPECIAL DE DESENVOLVIMENTO E APERFEIÇOAMENTO DAS ATIVIDADES DE FISCALIZAÇÃO

Art. 815. A remuneração devida ao Fundo Especial de
Desenvolvimento e Aperfeiçoamento das Atividades de
Fiscalização pelos permissionários ou concessionários de
recintos alfandegados, e pelos beneficiários de regimes
aduaneiros especiais ou aplicados em áreas especiais, se for
o caso, observará a legislação específica, inclusive as normas
complementares editadas pela Secretaria da Receita Federal
do Brasil.