[[Reg-AduMOC/CAPÍTULO II DO DESPACHO DE EXPORTAÇÃO]]

# SEÇÃO VII DO CANCELAMENTO DA DECLARAÇÃO DE EXPORTAÇÃO

Art. 594. A autoridade aduaneira poderá cancelar declaração
de exportação já registrada, de ofício ou a pedido do
exportador, observadas as condições estabelecidas em ato
normativo da Secretaria da Receita Federal do Brasil (Norma
Relativa ao Despacho Aduaneiro de Mercadorias, Artigo 54,
item 1, aprovada pela Decisão CMC no 50, de 2004, e
internalizada pelo Decreto no 6.870, de 2009). (Redação
dada pelo Decreto nº 7.213, de 2010).

Parágrafo único. O cancelamento da declaração não exime o
exportador da responsabilidade por eventuais infrações
(Norma Relativa ao Despacho Aduaneiro de Mercadorias,
Artigo 54, item 2, aprovada pela Decisão CMC no 50, de
2004, e internalizada pelo Decreto no 6.870, de 2009).
(Redação dada pelo Decreto nº 7.213, de 2010).