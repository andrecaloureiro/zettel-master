[[Reg-AduMOC/TÍTULO II DO CONTROLE ADUANEIRO DE VEÍCULOS]]

# CAPÍTULO IV DA DESCARGA E DA CUSTÓDIA DA MERCADORIA

Art. 63. A mercadoria descarregada de veículo procedente
do exterior será registrada pelo transportador, ou seu
representante, e pelo depositário, na forma e no prazo
estabelecidos pela Secretaria da Receita Federal do Brasil.

§ 1º O volume que, ao ser descarregado, apresentar-se
quebrado, com [[diferença de peso, com indícios de violação]]
ou de qualquer modo avariado, deverá ser objeto de
conserto e pesagem, fazendo-se, ato contínuo, a devida
anotação no registro de descarga, pelo depositário. (Incluído
pelo Decreto nº 8.010, de 2013)

§ 2º A autoridade aduaneira poderá determinar a aplicação
de [[cautelas fiscais]] e o isolamento dos volumes em local
próprio do recinto alfandegado, inclusive nos casos de
extravio ou avaria.(Incluído pelo Decreto nº 8.010, de 2013)