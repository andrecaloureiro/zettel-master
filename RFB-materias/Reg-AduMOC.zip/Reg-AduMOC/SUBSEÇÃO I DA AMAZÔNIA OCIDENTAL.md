[[Reg-AduMOC/SEÇÃO III DAS NORMAS ESPECÍFICAS]]

# SUBSEÇÃO I DA AMAZÔNIA OCIDENTAL

Art. 516. Os benefícios fiscais concedidos pelo Decreto-Lei nº
288, de 1967, estendem-se às áreas pioneiras, zonas de
fronteira e outras localidades da Amazônia Ocidental,
quanto aos seguintes produtos de origem estrangeira,
segundo pauta fixada pelos Ministros de Estado da Fazenda
e do Desenvolvimento, Indústria e Comércio Exterior
(Decreto-Lei no 356, de 15 de agosto de 1968, arts. 1º e 2º,
este com a redação dada pelo Decreto-Lei no 1.435, de 1975,
art. 3º):

(Pós-Edital)    913

I - motores marítimos de centro e de popa, seus acessórios e
pertences, bem como outros utensílios empregados na
atividade pesqueira, exceto explosivos e produtos utilizados
em sua fabricação;

II - máquinas, implementos e insumos utilizados na
agricultura, na pecuária e nas atividades afins;

III - máquinas para construção rodoviária;

IV - máquinas, motores e acessórios para instalação
industrial;

V - materiais de construção;

VI - produtos alimentares; e

VII - medicamentos.

§ 1º A Amazônia Ocidental é constituída pelos Estados do
Amazonas, do Acre, de Rondônia e de Roraima (Decreto-Lei
no 291, de 28 de fevereiro de 1967, art. 1º, § 4º).

§ 2º O despacho de importação dos bens relacionados no
caput poderá ser processado nas unidades aduaneiras de
Manaus (AM), Porto Velho (RO), Boa Vista (RR) e Rio Branco
(AC), ou em outros locais autorizados em ato normativo da
Secretaria da Receita Federal do Brasil.