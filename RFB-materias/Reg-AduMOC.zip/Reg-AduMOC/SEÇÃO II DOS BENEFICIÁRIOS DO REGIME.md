[[Reg-AduMOC/CAPÍTULO II DO TRÂNSITO ADUANEIRO]]

# SEÇÃO II DOS BENEFICIÁRIOS DO REGIME

Art. 321. Poderá ser beneficiário do regime:

I - o importador, nas modalidades referidas nos incisos I e VI
do art. 318;

II - o exportador, nas modalidades referidas nos incisos II, III
e VII do art. 318;

III - o depositante, na modalidade referida no inciso IV do art.
318;

IV - o representante, no País, de importador ou exportador
domiciliado no exterior, na modalidade referida no inciso V
do art. 318;

V - o depositário de recinto alfandegado, exceto na
modalidade referida no inciso V do caput do art. 318; e
(Redação dada pelo Decreto nº 10.550, de 2020)

VI - em qualquer caso:

a) o operador de transporte multimodal;

b) o transportador, habilitado nos termos da Seção III; e

c) o agente credenciado a efetuar operações de unitização
ou desunitização da carga em recinto alfandegado.