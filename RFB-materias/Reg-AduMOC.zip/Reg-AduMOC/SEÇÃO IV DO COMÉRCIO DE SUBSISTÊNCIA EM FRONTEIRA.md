[[Reg-AduMOC/CAPÍTULO V DAS ISENÇÕES DO IMPOSTO]]

# SEÇÃO IV DO COMÉRCIO DE SUBSISTÊNCIA EM FRONTEIRA

Art. 227. São isentos do imposto os bens levados para o
exterior no comércio característico das cidades situadas nas
fronteiras terrestres (Decreto-Lei nº 2.120, de 1984, art. 1º,
§ 2º, alínea "b").

Parágrafo único. Aplicam-se a esta Seção as normas previstas
no parágrafo único do art. 170.