[[Reg-AduMOC/TÍTULO I DO IMPOSTO SOBRE PRODUTOS INDUSTRIALIZADOS]]

# CAPÍTULO V DO PRAZO DE RECOLHIMENTO

Art. 242. O imposto será recolhido por ocasião do registro da
declaração de importação (Lei nº 4.502, de 1964, art. 26,
inciso I).