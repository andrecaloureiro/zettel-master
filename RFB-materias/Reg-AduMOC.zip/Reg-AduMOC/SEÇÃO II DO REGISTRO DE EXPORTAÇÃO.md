[[Reg-AduMOC/CAPÍTULO II DO DESPACHO DE EXPORTAÇÃO]]

# SEÇÃO II DO REGISTRO DE EXPORTAÇÃO

Art. 584. O registro de exportação compreende o conjunto
de informações de natureza comercial, financeira, cambial e
fiscal que caracteriza a operação de exportação de uma
mercadoria e define o seu enquadramento, devendo ser
efetuado de acordo com o estabelecido pela Secretaria de
Comércio Exterior.

Art. 585. O registro de exportação, no SISCOMEX, nos casos
previstos pela Secretaria de Comércio Exterior, é requisito
essencial para o despacho de exportação de mercadorias
nacionais ou nacionalizadas, ou de reexportação.