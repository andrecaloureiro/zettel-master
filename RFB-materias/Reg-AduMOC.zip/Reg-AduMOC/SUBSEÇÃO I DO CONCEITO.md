[[Reg-AduMOC/SEÇÃO I DA ADMISSÃO TEMPORÁRIA COM SUSPENSÃO TOTAL DO PAGAMENTO DE TRIBUTOS]]

# SUBSEÇÃO I DO CONCEITO

Art. 354. O regime aduaneiro especial de admissão
temporária com suspensão total do pagamento de tributos
permite a importação de bens que devam permanecer no
País durante prazo fixado, na forma e nas condições desta
Seção (Decreto-Lei nº 37, de 1966, art. 75, caput).