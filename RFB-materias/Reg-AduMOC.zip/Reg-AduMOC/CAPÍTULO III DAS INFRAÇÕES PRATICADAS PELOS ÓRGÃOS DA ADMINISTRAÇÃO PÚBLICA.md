[[Reg-AduMOC/TÍTULO V DAS DISPOSIÇÕES FINAIS]]

# CAPÍTULO III DAS INFRAÇÕES PRATICADAS PELOS ÓRGÃOS DA ADMINISTRAÇÃO PÚBLICA

Art. 742. Constitui [[falta grave]], praticada pelos chefes de
órgãos da administração pública direta ou indireta,
promover importação ao desamparo de licença de
importação ou documento de efeito equivalente, quando
exigível na forma da legislação em vigor (Decreto-Lei nº
1.455, de 1976, art. 34, caput).

§ 1º A apuração da irregularidade de que trata este artigo
será efetuada mediante [[inquérito]] determinado pela
autoridade competente (Decreto-Lei nº 1.455, de 1976, art.
34, § 1º).

§ 2º O prosseguimento do despacho aduaneiro dos bens
importados nas condições deste artigo ficará [[condicionado à conclusão]] do inquérito a que se refere o § 1º (Decreto-Lei nº
1.455, de 1976, art. 34, § 2º).

Art. 743. O Ministro de Estado da Fazenda[[MinEFaz]] disciplinará os
procedimentos fiscais a serem adotados pelas unidades
aduaneiras na ocorrência de infrações na importação, que
envolvam órgãos da administração pública (Decreto-Lei nº
1.455, de 1976, art. 34, § 3º).