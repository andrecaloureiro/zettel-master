[[Reg-AduMOC/CAPÍTULO V DAS ISENÇÕES DO IMPOSTO]]

# SEÇÃO I DO CAFÉ

Art. 218. São isentas do imposto as vendas de café para o
exterior (Decreto-Lei nº 2.295, de 21 de novembro de 1986,
art. 1º)