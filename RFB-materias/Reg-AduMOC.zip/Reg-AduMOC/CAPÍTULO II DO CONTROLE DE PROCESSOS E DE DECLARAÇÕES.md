[[Reg-AduMOC/TÍTULO III DO CONTROLE ADMINISTRATIVO ESPECÍFICO]]

# CAPÍTULO II DO CONTROLE DE PROCESSOS E DE DECLARAÇÕES

Art. 807. Os processos fiscais relativos a tributos ou
contribuições federais e a penalidades isoladas, bem como
as declarações, não poderão sair das unidades da Secretaria
da Receita Federal do Brasil, salvo quando se tratar de (Lei
nº 9.250, de 26 de dezembro de 1995, art. 38, caput):

I - encaminhamento de recursos à instância superior;

II - restituições de autos às unidades de origem; ou

III - encaminhamento de documentos para fins de
processamento de dados.

§ 1º Nos casos a que se referem os incisos I e II, deverá ficar
cópia autenticada dos documentos essenciais na unidade
aduaneira (Lei nº 9.250, de 1995, art. 38, § 1º).

§ 2º É facultado o fornecimento de cópia do processo ao
sujeito passivo ou a seu mandatário (Lei nº 9.250, de 1995,
art. 38, § 2º).