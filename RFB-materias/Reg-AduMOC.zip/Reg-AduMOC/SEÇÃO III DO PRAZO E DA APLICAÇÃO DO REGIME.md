[[Reg-AduMOC/CAPÍTULO VII DO REGIME DE ENTREPOSTO INDUSTRIAL SOB CONTROLE ADUANEIRO INFORMATIZADO - RECOF]]

# SEÇÃO III DO PRAZO E DA APLICAÇÃO DO REGIME

Art. 423. O prazo de suspensão do pagamento dos tributos
incidentes na importação será de até um ano, prorrogável
por período não superior a um ano.

§ 1º Em casos justificados, o prazo de que trata o caput
poderá ser prorrogado por período não superior, no total, a
cinco anos, observada a regulamentação editada pela
Secretaria da Receita Federal do Brasil.

§ 2º A partir do desembaraço aduaneiro para admissão no
regime, a empresa beneficiária responderá pela custódia e
guarda das mercadorias na condição de fiel depositária.

Art. 424. A normatização da aplicação do regime é de
competência da Secretaria da Receita Federal do Brasil, que
disporá quanto aos controles a serem exercidos (Decreto-Lei
nº 37, de 1966, art. 90, § 3º).