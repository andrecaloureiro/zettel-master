[[Reg-AduMOC/CAPÍTULO III DOS CASOS ESPECIAIS]]

# SEÇÃO XI DOS ANIMAIS E DOS SEUS PRODUTOS

Art. 620. Nenhuma espécie animal da fauna silvestre, assim
considerada os animais de quaisquer espécies, em qualquer
fase do seu desenvolvimento e que vivem naturalmente fora
do cativeiro, poderá ser introduzida no País sem parecer
técnico e licença expedida pelo Ministério do Meio Ambiente
(Lei no 5.197, de 3 de janeiro de 1967, arts. 1º, caput, e 4º).

Art. 621. É proibida a exportação de peles e couros de
anfíbios e répteis, em bruto (Lei nº 5.197, de 1967, art. 18).

Art. 622. O transporte para o exterior, de animais silvestres,
lepidópteros, e outros insetos e seus produtos, depende de
guia de trânsito, fornecida pelo Ministério do Meio
Ambiente (Lei nº 5.197, de 1967, art. 19, caput).

Parágrafo único. É dispensado dessa exigência o material
consignado a instituições científicas oficiais (Lei nº 5.197, de
1967, art. 19, parágrafo único).

##[[Reg-AduMOC/SUBSEÇÃO I DAS ESPÉCIES AQUÁTICAS]]

##[[Reg-AduMOC/SUBSEÇÃO II DOS EQÜÍDEOS]]