[[Reg-AduMOC/SEÇÃO VI DOS TERMOS, LIMITES E CONDIÇÕES]]

# SUBSEÇÃO XV DOS BENS IMPORTADOS PELAS ÁREAS DE LIVRE COMÉRCIO

Art. 176. A isenção do imposto na importação de bens
destinados às áreas de livre comércio observará o disposto
nos arts. 524 a 533.