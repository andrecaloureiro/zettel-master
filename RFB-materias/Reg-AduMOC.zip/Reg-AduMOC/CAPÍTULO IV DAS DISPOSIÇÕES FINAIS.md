[[Reg-AduMOC/TÍTULO II DA PENA DE PERDIMENTO]]

# CAPÍTULO IV DAS DISPOSIÇÕES FINAIS

Art. 701. Os veículos e as mercadorias sujeitos à pena de
perdimento serão [[guardados em nome e ordem do Ministro de Estado da Fazenda]], como medida acautelatória dos
interesses da Fazenda Nacional (Decreto-Lei nº 1.455, de
1976, art. 25).