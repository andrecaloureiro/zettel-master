[[Reg-AduMOC/CAPÍTULO I DO DESPACHO DE IMPORTAÇÃO]]

# SEÇÃO II DO LICENCIAMENTO DE IMPORTAÇÃO

Art. 550. A importação de mercadoria está sujeita, na forma
da legislação específica, a licenciamento, por meio do
SISCOMEX.

§ 1º A manifestação de outros órgãos, a cujo controle a
mercadoria importada estiver sujeita, também ocorrerá por
meio do SISCOMEX.

§ 2º No caso de despacho de importação realizado sem
registro de declaração no SISCOMEX, a manifestação dos
órgãos anuentes ocorrerá em campo específico da
declaração ou em documento próprio.

§ 3º Os Ministros de Estado da Fazenda e do
Desenvolvimento, Indústria e Comércio Exterior
determinarão, de forma conjunta, as informações de
natureza comercial, financeira, cambial e fiscal a serem
prestadas para fins de licenciamento.

§ 4º O licenciamento das importações enquadradas na [[alínea "e" do inciso I do caput e no § 1º do art. 136]] terá tratamento
prioritário e, quando aplicável, procedimento simplificado
(Lei nº 13.243, de 2016, art. 11). (Incluído pelo Decreto nº
9.283, de 2018)