[[Reg-AduMOC/SEÇÃO VI DOS TERMOS, LIMITES E CONDIÇÕES]]

# SUBSEÇÃO XX  DAS PARTES, PEÇAS E COMPONENTES DESTINADOS AO EMPREGO NA   CONSERVAÇÃO E MODERNIZAÇÃO DE EMBARCAÇÕES

Art. 181. A isenção do imposto na importação de partes,
peças e componentes destinados ao emprego na
conservação, modernização e conversão de embarcações
registradas no Registro Especial Brasileiro será reconhecida
somente se os serviços forem realizados em estaleiros navais
brasileiros (Lei no 9.493, de 1997, art. 11).