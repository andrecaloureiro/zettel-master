[[Reg-AduMOC/SEÇÃO XI DOS ANIMAIS E DOS SEUS PRODUTOS]]

# SUBSEÇÃO II DOS EQÜÍDEOS

Art. 624. É proibida a exportação de cavalos importados para
fins de reprodução, salvo quando tiverem permanecido no
País, como reprodutores, durante o prazo mínimo de três
anos consecutivos (Lei no 7.291, de 19 de dezembro de 1984,
art. 20, § 1º).

Art. 625. Os eqüídeos importados, em caráter temporário,
para participação em competições turfísticas, de hipismo e
pólo, exposições e feiras, e espetáculos circenses, deixarão o
País no prazo máximo de sessenta dias, contados do término
do respectivo evento, sendo facultada sua permanência
definitiva, mediante processo regular de importação (Lei nº
7.291, de 1984, art. 20, § 2º).