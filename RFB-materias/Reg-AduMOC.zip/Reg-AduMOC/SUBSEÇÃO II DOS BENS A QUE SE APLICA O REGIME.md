[[Reg-AduMOC/SEÇÃO I DA ADMISSÃO TEMPORÁRIA COM SUSPENSÃO TOTAL DO PAGAMENTO DE TRIBUTOS]]

# SUBSEÇÃO II DOS BENS A QUE SE APLICA O REGIME

Art. 355. O regime poderá ser aplicado aos bens relacionados
em ato normativo da Secretaria da Receita Federal do Brasil
e aos admitidos temporariamente ao amparo de acordos
internacionais.

(Pós-Edital)    891

§ 1º Os bens admitidos no regime ao amparo de acordos
internacionais firmados pelo País estarão sujeitos aos termos
e prazos neles previstos.

§ 2º A autoridade competente poderá indeferir pedido de
concessão do regime, em decisão fundamentada, da qual
caberá recurso, na forma estabelecida pela Secretaria da
Receita Federal do Brasil.

Art. 356. Os veículos matriculados em qualquer dos países
integrantes do Mercosul, de propriedade de pessoas físicas
residentes ou de pessoas jurídicas com sede social em tais
países, utilizados em viagens de turismo, circularão
livremente no País, com observância das condições previstas
na Resolução do Grupo do Mercado Comum - GMC no 35, de
2002, internalizada pelo Decreto no 5.637, de 26 de
dezembro de 2005, dispensado o cumprimento de
formalidades aduaneiras.

Art. 357. Considera-se em admissão temporária,
independentemente de qualquer procedimento
administrativo, o veículo que ingressar no território
aduaneiro a serviço de empresa estrangeira autorizada a
operar, no Brasil, nas atividades de transporte internacional
de carga ou passageiro. (Redação dada pelo Decreto nº
7.213, de 2010).