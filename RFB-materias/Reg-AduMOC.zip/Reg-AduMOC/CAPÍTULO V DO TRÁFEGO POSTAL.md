[[Reg-AduMOC/TÍTULO II DAS NORMAS ESPECIAIS]]

# CAPÍTULO V DO TRÁFEGO POSTAL

Art. 668. Compete à Secretaria da Receita Federal do Brasil o
controle aduaneiro de malas e remessas postais
internacionais (Decreto-Lei nº 37, de 1966, art. 61).