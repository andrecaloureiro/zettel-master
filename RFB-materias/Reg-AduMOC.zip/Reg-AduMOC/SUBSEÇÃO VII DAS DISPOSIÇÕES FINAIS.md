[[Reg-AduMOC/SEÇÃO I DA ADMISSÃO TEMPORÁRIA COM SUSPENSÃO TOTAL DO PAGAMENTO DE TRIBUTOS]]

# SUBSEÇÃO VII DAS DISPOSIÇÕES FINAIS

Art. 371. Poderá ser autorizada a substituição do beneficiário
do regime.

Parágrafo único. A autorização de que trata o caput não
implica reinício da contagem do prazo de permanência dos
bens no País.

Art. 372. A Secretaria da Receita Federal do Brasil poderá, no
âmbito de sua competência, editar atos normativos para a
implementação do disposto nesta Seção.