[[Reg-AduMOC/CAPÍTULO I DAS NORMAS GERAIS]]

# SEÇÃO IV DO CONTROLE DOS SOBRESSALENTES E DAS PROVISÕES DE BORDO

Art. 37. As mercadorias incluídas em listas de sobressalentes
e provisões de bordo deverão corresponder, em quantidade
e qualidade, às [[necessidades do serviço de manutenção do veículo e de uso ou consumo]] de sua tripulação e dos
passageiros.

§ 1º As mercadorias mencionadas no caput, que durante a
permanência do veículo na zona primária não forem
necessárias aos fins indicados, serão [[depositadas em compartimento fechado]], o qual poderá ser aberto somente
na presença da autoridade aduaneira ou após a saída do
veículo do local.

§ 2º A critério da autoridade aduaneira, poderá ser
dispensada a cautela prevista no § 1º, se a permanência do
veículo na zona primária for de curta duração.

Art. 38. A Secretaria da Receita Federal do Brasil disciplinará
o[[ funcionamento de lojas, bares e instalações semelhantes]],
em embarcações, aeronaves e outros veículos empregados
no transporte internacional, de modo a impedir a venda de
produtos sem o atendimento ao disposto na legislação
aduaneira (Decreto-Lei nº 37, de 1966, art. 40).