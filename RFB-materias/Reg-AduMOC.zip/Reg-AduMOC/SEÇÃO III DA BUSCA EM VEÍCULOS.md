[[Reg-AduMOC/CAPÍTULO I DAS NORMAS GERAIS]]

# SEÇÃO III DA BUSCA EM VEÍCULOS

Art. 34. A autoridade aduaneira poderá proceder a buscas
[[em qualquer veículo]] para [[prevenir e reprimir]] a ocorrência de
infração à legislação aduaneira, inclusive em momento
anterior à prestação das informações referidas no [[art. 31]]
(Decreto-Lei nº 37, de 1966, art. 37, § 4º, com a redação
dada pela Lei nº 10.833, de 2003, art. 77).

§ 1º A busca a que se refere o caput será [[precedida de comunicação, verbal ou por escrito]], ao responsável pelo
veículo.

§ 2º A Secretaria da Receita Federal do Brasil disporá sobre
os [[casos excepcionais em que será realizada a visita a
embarcações, prevista no art. 32 da Lei no 5.025, de 10 de
junho de 1966]] (Decreto-Lei nº 37, de 1966, art. 37, § 3º, com
a redação dada pela Lei nº 10.833, de 2003, art. 77).

Art. 35. A autoridade aduaneira [[poderá determinar a colocação de lacres nos compartimentos]] que contenham os
volumes ou as mercadorias a que se refere o [[§ 1º do art. 31
e na situação de que trata o § 1º do art. 37,]] podendo adotar
outras medidas de controle fiscal.

Art. 36. Havendo [[indícios de falsa declaração]] de conteúdo, a
autoridade aduaneira poderá determinar a descarga de
volume ou de unidade de carga, para a devida verificação,
lavrando-se termo.