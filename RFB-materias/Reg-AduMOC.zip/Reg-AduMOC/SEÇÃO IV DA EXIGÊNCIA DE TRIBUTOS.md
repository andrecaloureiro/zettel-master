[[Reg-AduMOC/CAPÍTULO VII DO REGIME DE ENTREPOSTO INDUSTRIAL SOB CONTROLE ADUANEIRO INFORMATIZADO - RECOF]]

# SEÇÃO IV DA EXIGÊNCIA DE TRIBUTOS

Art. 425. Findo o prazo fixado para a permanência da
mercadoria no regime, serão exigidos, em relação ao
estoque, os tributos suspensos, com os acréscimos legais
cabíveis (Decreto-Lei nº 37, de 1966, art. 90, § 2º).

Parágrafo único. O disposto no caput não dispensa o
cumprimento das exigências legais e regulamentares para a
permanência definitiva da mercadoria no País.

Art. 426. A Secretaria da Receita Federal do Brasil
estabelecerá a forma e o momento para o cálculo e para o
pagamento dos tributos.