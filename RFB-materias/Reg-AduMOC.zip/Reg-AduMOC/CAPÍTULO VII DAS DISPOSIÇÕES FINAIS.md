[[Reg-AduMOC/TÍTULO II DO IMPOSTO DE EXPORTAÇÃO]]

# CAPÍTULO VII DAS DISPOSIÇÕES FINAIS

Art. 235. Aplica-se, subsidiariamente, ao imposto de
exportação, no que couber, a legislação relativa ao imposto
de importação (Decreto-Lei no 1.578, de 1977, art. 8º).
Art. 236. Respeitadas as atribuições do Conselho Monetário
Nacional, a Câmara de Comércio Exterior expedirá as normas
necessárias à administração do imposto (Decreto-Lei nº
1.578, de 1977, art. 10, com a redação dada pela Medida
Provisória nº 2.158-35, de 2001, art. 51).