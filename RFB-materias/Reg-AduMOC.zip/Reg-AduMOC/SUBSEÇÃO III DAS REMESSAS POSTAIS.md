[[Reg-AduMOC/SEÇÃO III DAS NORMAS ESPECÍFICAS]]

# SUBSEÇÃO III DAS REMESSAS POSTAIS

Art. 518. Estão sujeitas à fiscalização e ao controle
aduaneiros, na área compreendida pela Zona Franca de
Manaus, as malas e remessas postais internacionais, bem
como as nacionais destinadas a outros pontos do território
aduaneiro.

Art. 519. As remessas postais com indícios de irregularidade
na internação serão retidas, para verificação, pela
autoridade aduaneira.