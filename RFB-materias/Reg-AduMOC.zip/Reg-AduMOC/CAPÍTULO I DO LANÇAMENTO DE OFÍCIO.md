[[Reg-AduMOC/TÍTULO I DO CRÉDITO TRIBUTÁRIO]]

# CAPÍTULO I DO LANÇAMENTO DE OFÍCIO

Art. 744. Sempre que for apurada infração às disposições
deste Decreto, que implique exigência de tributo ou
aplicação de penalidade pecuniária, o Auditor-Fiscal da
Receita Federal do Brasil deverá efetuar o correspondente
lançamento para fins de constituição do crédito tributário
(Lei no 5.172, de 1966, art. 142, caput; e Lei no 10.593, de
2002, art. 6º, inciso I, alínea "a", com a redação dada pela Lei
no 11.457, de 2007, art. 9º). (Redação dada pelo Decreto nº
7.213, de 2010).

Parágrafo único. O Auditor-Fiscal da Receita Federal do Brasil
não constituirá os créditos tributários relativos a matérias
que, em virtude de jurisprudência pacífica do Supremo
Tribunal Federal, ou do Superior Tribunal de Justiça, sejam
objeto de ato declaratório do Procurador-Geral da Fazenda
Nacional, aprovado pelo Ministro de Estado da Fazenda (Lei
no 10.522, de 19 de julho de 2002, art. 19, caput, inciso II e §
4º, com a redação dada pela Lei no 11.033, de 2004, art. 21).
(Incluído pelo Decreto nº 7.213, de 2010).

(Pós-Edital)    953

Art. 745. Poderá ser formalizada exigência de crédito
tributário correspondente exclusivamente a multa ou a juros
de mora, isolada ou conjuntamente (Lei nº 9.430, de 1996,
art. 43, caput).

Parágrafo único. Sobre o crédito constituído na forma do
caput, não pago no respectivo vencimento, incidirão juros de
mora (Lei nº 9.430, de 1996, art. 43, parágrafo único).