[[Reg-AduMOC/TÍTULO II DO PROCESSO FISCAL]]

# CAPÍTULO IX DAS DISPOSIÇÕES FINAIS

Art. 802. No âmbito do processo administrativo fiscal, fica
vedado ao julgador afastar a aplicação ou deixar de observar
tratado, acordo internacional, lei ou decreto, sob
fundamento de inconstitucionalidade (Decreto no 70.235,
de 1972, art. 26-A, caput, com a redação dada pela Lei no
11.941, de 2009, art. 25). (Redação dada pelo Decreto nº
7.213, de 2010).

Parágrafo único. O disposto no caput não se aplica aos casos
de tratado, acordo internacional, lei ou ato normativo
(Decreto no 70.235, de 1972, art. 26-A, § 6º, com a redação
dada pela Lei no 11.941, de 2009, art. 25): (Incluído pelo
Decreto nº 7.213, de 2010).

I - que já tenha sido declarado inconstitucional por decisão
plenária definitiva do Supremo Tribunal Federal; ou (Incluído
pelo Decreto nº 7.213, de 2010).

II - que fundamente crédito tributário objeto de: (Incluído
pelo Decreto nº 7.213, de 2010).

a) dispensa legal de constituição ou de ato declaratório do
Procurador-Geral da Fazenda Nacional, na forma dos arts. 18
e 19 da Lei no 10.522, de 19 de junho de 2002; (Incluído pelo
Decreto nº 7.213, de 2010).

b) súmula da Advocacia-Geral da União, na forma do art. 43
da Lei Complementar no 73, de 10 de fevereiro de 1993; ou
(Incluído pelo Decreto nº 7.213, de 2010).

c) pareceres do Advogado-Geral da União aprovados pelo
Presidente da República, na forma do art. 40 da Lei
Complementar no 73, de 1993. (Incluído pelo Decreto nº
7.213, de 2010).