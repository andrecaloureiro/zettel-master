[[Reg-AduMOC/CAPÍTULO III DAS ATIVIDADES RELACIONADAS AOS SERVIÇOS ADUANEIROS]]

# SEÇÃO II DAS ATIVIDADES RELACIONADAS AO TRANSPORTE MULTIMODAL INTERNACIONAL DE CARGA

Art. 811. O exercício da atividade de operador de transporte
multimodal, no transporte multimodal internacional de
cargas, depende de habilitação pela Secretaria da Receita
Federal do Brasil, para fins de controle aduaneiro (Lei nº
9.611, de 1998, art. 6º, caput, regulamentado pelo Decreto
no 3.411, de 12 de abril de 2000, art. 5º).

§ 1º Para a habilitação, que será concedida pelo prazo de dez
anos, prorrogável por igual período, será exigido do
interessado o cumprimento dos seguintes requisitos, sem
prejuízo de outros que venham a ser estabelecidos pela
Secretaria da Receita Federal do Brasil:

I - comprovação de registro na Secretaria-Executiva do
Ministério dos Transportes;

II - compromisso da prestação de garantia em valor
equivalente ao do crédito tributário suspenso, conforme
determinação da Secretaria da Receita Federal do Brasil,
mediante depósito em moeda, fiança idônea, inclusive
bancária, ou seguro aduaneiro em favor da União, a ser
efetivada quando da solicitação de operação de trânsito
aduaneiro; e

III - acesso ao SISCOMEX e a outros sistemas informatizados
de controle de carga ou de despacho aduaneiro.

§ 2º Está dispensada de apresentar a garantia a que se refere
o inciso II do § 1º a empresa cujo patrimônio líquido,
comprovado anualmente, por ocasião do balanço, exceder
R$ 2.000.000,00 (dois milhões de reais).

§ 3º Na hipótese de representação legal de empresa
estrangeira, o patrimônio líquido do representante, para
efeito do disposto no § 2º, poderá ser substituído por carta
de crédito de valor equivalente.