[[Reg-AduMOC/CAPÍTULO I DO DESPACHO DE IMPORTAÇÃO]]

# SEÇÃO IV DA INSTRUÇÃO DA DECLARAÇÃO DE IMPORTAÇÃO

Art. 553. A declaração de importação será obrigatoriamente
instruída com (Decreto-Lei nº 37, de 1966, art. 46, caput,
com a redação dada pelo Decreto-Lei nº 2.472, de 1988, art.
2º): (Redação dada pelo Decreto nº 8.010, de 2013)

I - a via original do conhecimento de carga ou documento de
efeito equivalente;

II - a via original da fatura comercial, assinada pelo
exportador; e (Redação dada pelo Decreto nº 8.010, de
2013)

III - o comprovante de pagamento dos tributos, se exigível.
(Redação dada pelo Decreto nº 8.010, de 2013)

Parágrafo único. Poderão ser exigidos outros documentos
instrutivos da declaração aduaneira em decorrência de
acordos internacionais ou por força de lei, de regulamento
ou de outro ato normativo. (Incluído pelo Decreto nº 8.010,
de 2013)

##[[Reg-AduMOC/SUBSEÇÃO I DO CONHECIMENTO DE CARGA]]

##[[Reg-AduMOC/SUBSEÇÃO II DA FATURA COMERCIAL]]

##[[Reg-AduMOC/SUBSEÇÃO III DOS OUTROS DOCUMENTOS INSTRUTIVOS DA DECLARAÇÃO]]