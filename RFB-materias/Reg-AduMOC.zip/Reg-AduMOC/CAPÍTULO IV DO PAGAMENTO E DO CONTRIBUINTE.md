[[Reg-AduMOC/TÍTULO II DO IMPOSTO DE EXPORTAÇÃO]]

# CAPÍTULO IV DO PAGAMENTO E DO CONTRIBUINTE

Art. 216. O pagamento do imposto será realizado na forma e
no prazo fixados pelo Ministro de Estado da Fazenda, que
poderá determinar sua exigibilidade antes da efetiva saída
do território aduaneiro da mercadoria a ser exportada
(Decreto-Lei nº 1.578, de 1977, art. 4º, caput).

§ 1º Não efetivada a exportação da mercadoria ou ocorrendo
o seu retorno nas condições dos incisos I a V do art. 70, o
imposto pago será compensado, na forma do art. 113, ou
restituído, mediante requerimento do interessado,
acompanhado da respectiva documentação comprobatória
(Decreto-Lei nº 1.578, de 1977, art. 6º).

§ 2º Poderá ser dispensada a cobrança do imposto em
função do destino da mercadoria a ser exportada,
observadas as normas editadas pelo Ministro de Estado da
Fazenda (Decreto-Lei nº 1.578, de 1977, art. 4º, parágrafo
único, com a redação dada pela Lei nº 9.716, de 1998, art.
1º).

Art. 217. É contribuinte do imposto o exportador, assim
considerada qualquer pessoa que promova a saída de
mercadoria do território aduaneiro (Decreto-Lei nº 1.578, de
1977, art. 5º).