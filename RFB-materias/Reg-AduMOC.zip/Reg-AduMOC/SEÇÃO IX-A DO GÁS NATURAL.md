[[Reg-AduMOC/CAPÍTULO III DOS CASOS ESPECIAIS]]

# SEÇÃO IX-A DO GÁS NATURAL

(Incluído pelo Decreto nº 7.213, de 2010).

Art. 618-A. Qualquer empresa ou consórcio de empresas,
desde que constituídos sob as leis brasileiras, com sede e
administração no País, poderão receber autorização do
Ministério de Minas e Energia para exercer as atividades de
importação e exportação de gás natural (Lei no 11.909, de 4
de março de 2009, art. 36, caput). (Incluído pelo Decreto nº
7.213, de 2010).

Parágrafo único. O exercício das atividades de importação e
exportação de gás natural observará as diretrizes
estabelecidas pelo Conselho Nacional de Política Energética
(Lei nº 11.909, de 2009, art. 36, parágrafo único). (Incluído
pelo Decreto nº 7.213, de 2010).