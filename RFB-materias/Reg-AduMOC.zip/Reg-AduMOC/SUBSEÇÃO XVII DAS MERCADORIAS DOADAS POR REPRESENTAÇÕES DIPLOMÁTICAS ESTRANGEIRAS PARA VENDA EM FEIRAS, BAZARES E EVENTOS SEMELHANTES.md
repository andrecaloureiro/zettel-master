[[Reg-AduMOC/SEÇÃO VI DOS TERMOS, LIMITES E CONDIÇÕES]]

# SUBSEÇÃO XVII DAS MERCADORIAS DOADAS POR REPRESENTAÇÕES DIPLOMÁTICAS ESTRANGEIRAS PARA VENDA EM FEIRAS, BAZARES E EVENTOS SEMELHANTES

Art. 178. As entidades beneficentes reconhecidas como de
utilidade pública poderão vender em feiras, bazares e
eventos semelhantes, com isenção do imposto, mercadorias
estrangeiras recebidas em doação de representações
diplomáticas estrangeiras sediadas no País, observada a
regulamentação editada pelo Ministério da Fazenda (Lei no
8.218, de 1991, art. 34, caput).

Parágrafo único. O produto líquido da venda dos bens
recebidos em doação, na forma do caput, terá como
destinação exclusiva o desenvolvimento de atividades
beneficentes no País (Lei nº 8.218, de 1991, art. 34,
parágrafo único).