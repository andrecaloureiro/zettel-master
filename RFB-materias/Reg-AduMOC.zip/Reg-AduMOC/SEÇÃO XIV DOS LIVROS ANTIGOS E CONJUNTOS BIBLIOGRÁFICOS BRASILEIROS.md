[[Reg-AduMOC/CAPÍTULO III DOS CASOS ESPECIAIS]]

# SEÇÃO XIV DOS LIVROS ANTIGOS E CONJUNTOS BIBLIOGRÁFICOS BRASILEIROS

Art. 631. É proibida a saída do País, ressalvados os casos
autorizados pelo Ministério da Cultura, de (Lei no 5.471, de
9 de julho de 1968, arts. 1º, parágrafo único, alíneas "a" e
"b", e 2º):

I - bibliotecas e acervos documentais constituídos de obras
brasileiras ou sobre o Brasil, editadas nos séculos XVI a XIX;

II - obras e documentos compreendidos no inciso I, que, por
desmembramento dos conjuntos bibliográficos, ou
isoladamente, hajam sido vendidos; e

III - coleções de periódicos que já tenham sido publicados há
mais de dez anos, bem como quaisquer originais e cópias
antigas de partituras musicais.

Art. 632. A infringência do disposto no art. 631 será punida
com a apreensão dos bens (Lei nº 5.471, de 1968, art. 3º,
caput).

Parágrafo único. A destinação dos bens apreendidos será
feita em proveito do patrimônio público, após a
manifestação do Ministério da Cultura (Lei nº 5.471, de 1968,
art. 3º, parágrafo único).