[[Reg-AduMOC/CAPÍTULO II DO TRÂNSITO ADUANEIRO]]

# SEÇÃO VII DA AVARIA E DO EXTRAVIO NO TRÂNSITO

(Redação dada pelo Decreto nº 8.010, de 2013)

Art. 345. Quando a constatação de extravio ou avaria ocorrer
no local de origem, a autoridade aduaneira poderá, não
havendo inconveniente, permitir o trânsito aduaneiro da
mercadoria avariada ou da partida com extravio, após a
determinação da quantidade extraviada, observado o
disposto no art. 660. (Redação dada pelo Decreto nº 8.010,
de 2013)

§ 1º Caso o extravio ou avaria ocorram no percurso do
trânsito, a autoridade aduaneira poderá, após comunicada
na forma do parágrafo único do art. 340, autorizar o
prosseguimento do trânsito até o local de destino, adotadas
as cautelas fiscais cabíveis. (Incluído pelo Decreto nº 8.010,
de 2013)

§ 2º Em qualquer caso, poderá ser autorizado o início ou
prosseguimento do trânsito, dispensado o lançamento a que
se refere o art. 660, na hipótese de o beneficiário do regime
assumir espontaneamente o pagamento dos créditos
decorrentes do extravio. (Incluído pelo Decreto nº 8.010, de
2013)