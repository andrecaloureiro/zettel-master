[[Reg-AduMOC/TÍTULO I DO IMPOSTO DE IMPORTAÇÃO]]

# CAPÍTULO VI DO PAGAMENTO E DO DEPÓSITO

Art. 107. O imposto será pago na data do registro da
declaração de importação (Decreto-Lei no 37, de 1966, art.
27).

Parágrafo único. O Ministro de Estado da Fazenda poderá
fixar, em casos especiais, outros momentos para o
pagamento do imposto.

Art. 108. A importância a pagar será a resultante da
apuração do total do imposto, na declaração de importação
ou em documento de efeito equivalente.

Art. 109. O depósito para garantia de qualquer natureza será
feito na Caixa Econômica Federal, na forma da legislação
específica.