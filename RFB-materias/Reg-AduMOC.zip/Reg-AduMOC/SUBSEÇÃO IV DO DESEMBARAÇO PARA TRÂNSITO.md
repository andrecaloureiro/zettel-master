[[Reg-AduMOC/SEÇÃO IV DO DESPACHO PARA TRÂNSITO]]

# SUBSEÇÃO IV DO DESEMBARAÇO PARA TRÂNSITO

Art. 334. O despacho para trânsito completa-se com o
desembaraço aduaneiro, após a adoção das providências
previstas na Subseção III.