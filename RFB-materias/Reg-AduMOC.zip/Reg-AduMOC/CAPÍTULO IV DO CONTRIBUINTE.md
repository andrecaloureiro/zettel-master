[[Reg-AduMOC/TÍTULO I DO IMPOSTO SOBRE PRODUTOS INDUSTRIALIZADOS]]

# CAPÍTULO IV DO CONTRIBUINTE

Art. 241. É contribuinte do imposto, na importação, o
importador, em relação ao fato gerador decorrente do
desembaraço aduaneiro (Lei nº 4.502, de 1964, art. 35, inciso
I, alínea "b").