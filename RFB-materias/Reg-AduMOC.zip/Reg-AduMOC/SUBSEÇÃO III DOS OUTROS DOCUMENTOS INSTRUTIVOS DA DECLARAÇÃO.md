[[Reg-AduMOC/SEÇÃO IV DA INSTRUÇÃO DA DECLARAÇÃO DE IMPORTAÇÃO]]

# SUBSEÇÃO III DOS OUTROS DOCUMENTOS INSTRUTIVOS DA DECLARAÇÃO

Art. 563. No caso de mercadoria que goze de tratamento
tributário favorecido em razão de sua origem, a
comprovação desta será feita por qualquer meio julgado
idôneo, em conformidade com o estabelecido no
correspondente acordo internacional, atendido o disposto
no art. 117.