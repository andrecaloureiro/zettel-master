[[Reg-AduMOC/CAPÍTULO III DAS ATIVIDADES RELACIONADAS AOS SERVIÇOS ADUANEIROS]]

# SEÇÃO IV DAS ATIVIDADES DE PERÍCIA E DE ASSISTÊNCIA TÉCNICA

Art. 813. A perícia para identificação e quantificação de
mercadoria importada ou a exportar, bem como a avaliação
de equipamentos de segurança e sistemas informatizados, e
a emissão de laudos periciais sobre o estado e o valor
residual de bens, será proporcionada:

I - pelos laboratórios da Secretaria da Receita Federal do
Brasil;

II - por órgãos ou entidades da administração pública; ou

III - por entidades privadas e técnicos, especializados,
previamente credenciados.

Parágrafo único. A Secretaria da Receita Federal do Brasil
expedirá ato normativo em que:

I - regulará o processo de credenciamento dos órgãos, das
entidades e dos técnicos a que se referem os incisos II e III do
caput; e

II - estabelecerá o responsável, o valor e a forma de
retribuição pelos serviços prestados.

Art. 814. Para fins de acompanhamento da perícia referida
no art. 813, a pessoa que comprove legítimo interesse no
caso poderá utilizar assistência técnica.

Parágrafo único. O assistente técnico será indicado
livremente, sendo sua remuneração estabelecida em
contrato.