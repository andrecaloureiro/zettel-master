[[Reg-AduMOC/CAPÍTULO VII DA SUSPENSÃO DO PAGAMENTO]]

# SEÇÃO X DA ACETONA DESTINADA À ELABORAÇÃO DE DEFENSIVOS AGROPECUÁRIOS

Art. 291. A importação de acetona classificada no código
2914.11.00 da Nomenclatura Comum do Mercosul será
efetuada com suspensão do pagamento da Contribuição
para o PIS/PASEP-Importação e da COFINS-Importação (Lei
no 11.727, de 2008, art. 25, caput).

§ 1º O disposto no caput alcança exclusivamente a acetona
destinada a fabricação de monoisopropilamina utilizada na
elaboração de defensivos agropecuários classificados na
posição 38.08 da Nomenclatura Comum do Mercosul e
importada diretamente pela pessoa jurídica fabricante (Lei
nº 11.727, de 2008, art. 25, §§ 1º e 2º).

§ 2º A pessoa jurídica que der à acetona destinação diversa
daquela prevista no § 1º fica obrigada ao recolhimento das
contribuições não pagas, acrescidas de juros e multa de
mora, na forma da lei, contados da data do registro da
declaração de importação (Lei nº 11.727, de 2008, art. 25, §
3º).

§ 3º Na hipótese de não ser efetuado o recolhimento na
forma do § 2º, caberá lançamento de ofício, com aplicação
de juros e da multa de que trata art. 725 (Lei nº 11.727, de
2008, art. 25, § 4º).

§ 4º Nas hipóteses de que tratam os §§ 2º e 3º, a pessoa
jurídica produtora de defensivos agropecuários será
responsável solidária com a pessoa jurídica fabricante da
monoisopropilamina pelo pagamento das contribuições
devidas e respectivos acréscimos legais (Lei nº 11.727, de
2008, art. 25, § 5º).