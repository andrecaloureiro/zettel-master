#Dec6759-2009

Decreto nº 6.759/2009

Regulamenta a administração das atividades aduaneiras, e
a fiscalização, o controle e a tributação das operações de
comércio exterior.

O PRESIDENTE DA REPÚBLICA, no uso da atribuição que lhe
confere o art. 84, inciso IV, da Constituição,

DECRETA:
                                                     
Art. 1º A administração das atividades aduaneiras, e a
fiscalização, o controle e a tributação das operações de
comércio exterior serão exercidos em conformidade com o
disposto neste Decreto.


[[Reg-AduMOC/TÍTULO I DA JURISDIÇÃO ADUANEIRA]]

[[Reg-AduMOC/TÍTULO II DO CONTROLE ADUANEIRO DE VEÍCULOS]]

------------------
[[Reg-AduMOC/LIVRO II   DOS IMPOSTOS DE IMPORTAÇÃO E DE EXPORTAÇÃO]]