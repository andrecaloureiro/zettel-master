[[Reg-AduMOC/TÍTULO II DO PROCESSO FISCAL]]

# CAPÍTULO I DO PROCESSO DE DETERMINAÇÃO E EXIGÊNCIA DE CRÉDITO TRIBUTÁRIO

Art. 768. A determinação e a exigência dos créditos
tributários decorrentes de infração às normas deste Decreto
serão apuradas mediante processo administrativo fiscal, na
forma do Decreto nº 70.235, de 1972 (Decreto-Lei no 822,
de 5 de setembro de 1969, art. 2º; e Lei nº 10.336, de 2001,
art. 13, parágrafo único).

§ 1º O disposto no caput aplica-se inclusive à multa referida
no § 1º do art. 689 (Lei no 10.833, de 2003, art. 73, § 2º).
(Incluído pelo Decreto nº 7.213, de 2010).

§ 2º O procedimento referido no § 2º do art. 570 poderá ser
aplicado ainda a outros casos, na forma estabelecida pela
Secretaria da Receita Federal do Brasil. (Incluído pelo
Decreto nº 7.213, de 2010).

##[[Reg-AduMOC/SEÇÃO ÚNICA DO PROCESSO DE DETERMINAÇÃO E EXIGÊNCIA DAS MEDIDAS DE SALVAGUARDA]]