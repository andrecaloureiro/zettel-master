[[Reg-AduMOC/CAPÍTULO VII DA SUSPENSÃO DO PAGAMENTO]]

# SEÇÃO V DA PESSOA JURÍDICA PREPONDERANTEMENTE EXPORTADORA

Art. 276. A pessoa jurídica preponderantemente
exportadora, assim considerada aquela cuja receita bruta
decorrente de exportação para o exterior, no ano-calendário
imediatamente anterior ao da aquisição, houver sido igual
ou superior a setenta por cento de sua receita bruta total de
venda de bens e serviços no mesmo período, após excluídos
os impostos e contribuições incidentes sobre a venda,
poderá importar com suspensão do pagamento da
contribuição para o PIS/PASEP-Importação e da COFINS-
Importação matérias-primas, produtos intermediários e
materiais de embalagem (Lei nº 10.865, de 2004, art. 40,
caput, § 1º, com a redação dada pela Lei no 11.529, de 22 de
outubro de 2007, art. 4º, e § 6º, com a redação dada pela Lei
nº 11.482, de 31 de maio de 2007, art. 17).

(Pós-Edital)    881
                1029