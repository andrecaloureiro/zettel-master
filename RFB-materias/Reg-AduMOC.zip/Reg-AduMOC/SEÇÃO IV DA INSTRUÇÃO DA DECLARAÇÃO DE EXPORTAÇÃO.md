[[Reg-AduMOC/CAPÍTULO II DO DESPACHO DE EXPORTAÇÃO]]

# SEÇÃO IV DA INSTRUÇÃO DA DECLARAÇÃO DE EXPORTAÇÃO

Art. 588. A declaração de exportação será instruída com:

I - a primeira via da nota fiscal;

II - a via original do conhecimento e do manifesto
internacional de carga, nas exportações por via terrestre,
fluvial ou lacustre; e

III - outros documentos exigidos na legislação específica.

Parágrafo único. Os documentos instrutivos da declaração
de exportação serão entregues à autoridade aduaneira, na
forma, no prazo e nas condições estabelecidos pela
Secretaria da Receita Federal do Brasil.