[[Reg-AduMOC/LIVRO III DOS DEMAIS IMPOSTOS, E DAS TAXAS E CONTRIBUIÇÕES, DEVIDOS NA IMPORTAÇÃO]]

## TÍTULO V DA TAXA DE UTILIZAÇÃO DO SISCOMEX

Art. 306. A taxa de utilização do SISCOMEX, administrada
pela Secretaria da Receita Federal do Brasil, será devida no
registro da declaração de importação, à razão de (Lei no
9.716, de 1998, art. 3º, caput e § 1º):

I - [[R$ 30,00 (trinta reais) por declaração]] de importação; e

II - [[R$ 10,00 (dez reais) por adição]] da declaração de
importação, observado o limite fixado pela Secretaria da
Receita Federal do Brasil.

§ 1º Os valores referidos no caput poderão ser reajustados,
anualmente, mediante ato do Ministro de Estado da
Fazenda, conforme a variação dos custos de operação e dos
investimentos no SISCOMEX (Lei nº 9.716, de 1998, art. 3º, §
2º).

§ 2º Aplicam-se à cobrança da taxa de que trata este artigo
as normas referentes ao imposto de importação (Lei nº
9.716, de 1998, art. 3º, § 3º).