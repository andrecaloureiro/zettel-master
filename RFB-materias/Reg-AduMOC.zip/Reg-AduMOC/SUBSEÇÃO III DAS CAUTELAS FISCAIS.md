[[Reg-AduMOC/SEÇÃO IV DO DESPACHO PARA TRÂNSITO]]

# SUBSEÇÃO III DAS CAUTELAS FISCAIS

Art. 333. Ultimada a conferência, poderão ser adotadas
cautelas fiscais visando a impedir a violação dos volumes,
recipientes e, se for o caso, do veículo transportador, na
forma estabelecida pela Secretaria da Receita Federal do
Brasil (Decreto-Lei nº 37, de 1966, art. 74, § 2º).

§ 1º São cautelas fiscais:

I - a lacração e a aplicação de outros dispositivos de
segurança; e

II - o acompanhamento fiscal, que somente será
determinado em casos especiais.

§ 2º Os dispositivos de segurança somente poderão ser
rompidos ou suprimidos na presença da fiscalização, salvo
disposição normativa em contrário.

§ 3º As despesas realizadas pelas unidades aduaneiras da
Secretaria da Receita Federal do Brasil, com a aplicação de
dispositivos de segurança em volumes, veículos e unidades
de carga, deverão ser ressarcidas pelos interessados, na
forma estabelecida em ato da Secretaria da Receita Federal
do Brasil (Decreto-Lei nº 2.472, de 1988, art. 9º).