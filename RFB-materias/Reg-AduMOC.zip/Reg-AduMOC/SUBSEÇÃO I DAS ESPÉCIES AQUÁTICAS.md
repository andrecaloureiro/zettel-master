[[Reg-AduMOC/SEÇÃO XI DOS ANIMAIS E DOS SEUS PRODUTOS]]

# SUBSEÇÃO I DAS ESPÉCIES AQUÁTICAS

Art. 623. A importação de espécies aquáticas para fins
ornamentais e de aquicultura, em qualquer fase do ciclo
vital, dependerá de permissão do órgão competente (Lei no
11.959, de 29 de junho de 2009, art. 25, inciso II). (Redação
dada pelo Decreto nº 7.213, de 2010).