[[Reg-AduMOC/SEÇÃO IV DA INSTRUÇÃO DA DECLARAÇÃO DE IMPORTAÇÃO]]

# SUBSEÇÃO I DO CONHECIMENTO DE CARGA

Art. 554. O conhecimento de carga original, ou documento
de efeito equivalente, constitui prova de posse ou de
propriedade da mercadoria (Decreto-Lei nº 37, de 1966, art.
46, caput, com a redação dada pelo Decreto-Lei no 2.472, de
1988, art. 2º).

Parágrafo único. A Secretaria da Receita Federal do Brasil
poderá dispor sobre hipóteses de não-exigência do
conhecimento de carga para instrução da declaração de
importação.

Art. 555. A cada conhecimento de carga deverá
corresponder uma única declaração de importação, salvo
exceções estabelecidas pela Secretaria da Receita Federal do
Brasil.

Art. 556. Os requisitos formais e intrínsecos, a
transmissibilidade e outros aspectos atinentes aos
conhecimentos de carga devem regular-se pelos dispositivos
da legislação comercial e civil, sem prejuízo da aplicação das
normas tributárias quanto aos respectivos efeitos fiscais.