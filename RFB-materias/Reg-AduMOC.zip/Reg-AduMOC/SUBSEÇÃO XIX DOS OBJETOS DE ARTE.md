[[Reg-AduMOC/SEÇÃO VI DOS TERMOS, LIMITES E CONDIÇÕES]]

# SUBSEÇÃO XIX DOS OBJETOS DE ARTE

Art. 180. A isenção do imposto na importação de objetos de
arte somente beneficia aqueles classificados nas posições
9701, 9702, 9703 e 9706 da Nomenclatura Comum do
Mercosul, recebidos, em doação, por museus (Lei nº 8.961,
de 1994, art. 1º).

Parágrafo único. Os museus a que se refere o caput deverão
ser instituídos e mantidos pelo poder público ou por outras
entidades culturais reconhecidas como de utilidade pública
(Lei nº 8.961, de 1994, art. 1º).