[[Reg-AduMOC/TÍTULO II DAS NORMAS ESPECIAIS]]

# CAPÍTULO VI DO TRÁFEGO DE CABOTAGEM

Art. 669. Para os efeitos deste Decreto, entende-se por
cabotagem o transporte efetuado entre portos e aeroportos
nacionais (Decreto-Lei nº 37, de 1966, art. 62).

(Pós-Edital)    934

Art. 670. As mercadorias nacionais ou nacionalizadas,
destinadas ao mercado interno em transporte de
cabotagem, não poderão ser depositadas em recinto
alfandegado.

Parágrafo único. A autoridade aduaneira, para atender a
situações especiais, poderá autorizar o depósito das
mercadorias de que trata o caput em recinto alfandegado,
no prazo e nas condições que estabelecer.

Art. 671. A Secretaria da Receita Federal do Brasil poderá
estabelecer normas relativas ao controle aduaneiro de
mercadorias no tráfego de cabotagem, quando realizado
para portos e aeroportos alfandegados, ou a partir desses
locais (Decreto-Lei nº 37, de 1966, art. 62).

Art. 672. A autoridade aduaneira poderá, quando necessário,
determinar a realização de busca em aeronave ou
embarcação, utilizada no transporte de cabotagem, ou seu
acompanhamento fiscal.