[[Reg-AduMOC/TÍTULO IV DA CONTRIBUIÇÃO DE INTERVENÇÃO NO DOMÍNIO ECONÔMICO - COMBUSTÍVEIS]]

# CAPÍTULO II DO CONTRIBUINTE E DO RESPONSÁVEL SOLIDÁRIO

Art. 300. É contribuinte da CIDE-Combustíveis o importador,
pessoa física ou jurídica, dos combustíveis líquidos

(Pós-Edital)    885

relacionados no art. 299 (Lei nº 10.336, de 2001, art. 2º,
caput).

Art. 301. É responsável solidário pela CIDE-Combustíveis o
adquirente de mercadoria de procedência estrangeira, no
caso de importação realizada por sua conta e ordem, por
intermédio de pessoa jurídica importadora (Lei nº 10.336, de
2001, art. 11).