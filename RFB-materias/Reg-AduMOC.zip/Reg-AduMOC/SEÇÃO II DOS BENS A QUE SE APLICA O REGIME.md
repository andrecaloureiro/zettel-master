[[Reg-AduMOC/CAPÍTULO IX DA EXPORTAÇÃO TEMPORÁRIA]]

# SEÇÃO II DOS BENS A QUE SE APLICA O REGIME

Art. 432. O regime será aplicado aos bens relacionados em
ato normativo da Secretaria da Receita Federal do Brasil e
aos exportados temporariamente ao amparo de acordos
internacionais.

Parágrafo único. Os bens admitidos no regime ao amparo de
acordos internacionais firmados pelo País estarão sujeitos
aos termos e prazos neles previstos.

Art. 433. Não será permitida a exportação temporária de
mercadorias cuja exportação definitiva esteja proibida,
exceto nos casos em que haja autorização do órgão
competente.

(Pós-Edital)    902