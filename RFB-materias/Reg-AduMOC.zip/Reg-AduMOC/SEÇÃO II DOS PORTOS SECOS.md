[[Reg-AduMOC/CAPÍTULO III DOS RECINTOS ALFANDEGADOS]]

## SEÇÃO II DOS PORTOS SECOS

Art. 11. Portos secos são [[recintos alfandegados de uso público]] nos quais são executadas operações de
movimentação, armazenagem e despacho aduaneiro de
mercadorias e de bagagem, sob controle aduaneiro.

§ 1º Os portos secos [[não poderão ser instalados na zona primária]] de portos e aeroportos alfandegados.

§ 2º Os portos secos poderão ser autorizados a operar com
carga de importação, de exportação ou ambas, tendo em
vista as [[necessidades e condições locais]].

Art. 12. As operações de movimentação e armazenagem de
mercadorias sob controle aduaneiro, bem como a prestação
de serviços conexos, em porto seco, sujeitam-se ao regime de concessão ou de permissão (Lei no 9.074, de 7 de julho de
1995, art. 1º, inciso VI).

Parágrafo único. A execução das operações e a prestação dos
serviços referidos no caput serão efetivadas mediante o
[[regime de permissão]], salvo quando os serviços devam ser
prestados em porto seco instalado em [[imóvel pertencente à União, caso em que será adotado o regime de concessão]]
precedida da execução de obra pública.