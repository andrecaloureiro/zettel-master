[[Reg-AduMOC/SEÇÃO VI DOS TERMOS, LIMITES E CONDIÇÕES]]

# SUBSEÇÃO XIV  DOS MEDICAMENTOS E DO INSTRUMENTAL CIENTÍFICO  DESTINADOS AO TRATAMENTO E À PESQUISA DA SÍNDROME DA DEFICIÊNCIA IMUNOLÓGICA ADQUIRIDA

Art. 175. A isenção do imposto referida na alínea "j" do inciso
II do art. 136 aplica-se à importação de medicamentos
utilizados exclusivamente no tratamento de aidéticos, e de
instrumental de uso exclusivo na pesquisa da doença, na
forma da legislação específica.