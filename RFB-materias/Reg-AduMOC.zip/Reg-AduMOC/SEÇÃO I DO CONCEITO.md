#corrigir: existem varios ponteiros para cá e só uma definicao

[[Reg-AduMOC/CAPÍTULO I DA ZONA FRANCA DE MANAUS]]

# SEÇÃO I DO CONCEITO

Art. 504. A Zona Franca de Manaus é uma área de livre
comércio de importação e de exportação e de incentivos
fiscais especiais, estabelecida com a finalidade de criar no
interior da Amazônia um centro industrial, comercial e
agropecuário, dotado de condições econômicas que
permitam seu desenvolvimento, em face dos fatores locais e
da grande distância a que se encontram os centros
consumidores de seus produtos (Decreto-Lei nº 288, de
1967, art. 1º).
