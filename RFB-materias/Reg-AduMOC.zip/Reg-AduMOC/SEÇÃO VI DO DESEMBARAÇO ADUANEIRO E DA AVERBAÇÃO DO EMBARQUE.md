[[Reg-AduMOC/CAPÍTULO II DO DESPACHO DE EXPORTAÇÃO]]

# SEÇÃO VI DO DESEMBARAÇO ADUANEIRO E DA AVERBAÇÃO DO EMBARQUE

Art. 591. Desembaraço aduaneiro na exportação é o ato pelo
qual é registrada a conclusão da conferência aduaneira, e
autorizado o embarque ou a transposição de fronteira da
mercadoria.

Parágrafo único. Constatada divergência ou infração que não
impeça a saída da mercadoria do País, o desembaraço será
realizado, sem prejuízo da formalização de exigências, desde
que assegurados os meios de prova necessários.

Art. 592. A mercadoria a ser reexportada somente será
desembaraçada após o pagamento das multas a que estiver
sujeita (Decreto-Lei nº 37, de 1966, art. 71, § 6º, com a
redação dada pelo Decreto-Lei no 2.472, de 1988, art. 1º).

Art. 593. A averbação do embarque consiste na confirmação
da saída da mercadoria do País.