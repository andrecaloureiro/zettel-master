[[Reg-AduMOC/TÍTULO II DA CONTRIBUIÇÃO PARA O PISPASEP-IMPORTAÇÃO E DA COFINS-IMPORTAÇÃO]]

# CAPÍTULO VI DO PAGAMENTO

Art. 259. A contribuição para o PIS/PASEP-Importação e a
COFINS-Importação serão pagas na data do registro da
declaração de importação (Lei nº 10.865, de 2004, art.13,
inciso I).

Parágrafo único. Na hipótese que trata o inciso III do art. 252,
as contribuições a que se refere o caput serão pagas na data
de registro da declaração de importação, com os acréscimos
legais, contados da data de vencimento do prazo de
permanência do bem no recinto alfandegado (Lei nº 10.865,
de 2004, art.13, inciso III).