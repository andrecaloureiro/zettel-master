[[Reg-AduMOC/TÍTULO IV DA CONTRIBUIÇÃO DE INTERVENÇÃO NO DOMÍNIO ECONÔMICO - COMBUSTÍVEIS]]

# CAPÍTULO IV DAS ISENÇÕES

Art. 305. São isentos da CIDE-Combustíveis os bens dos tipos
e em quantidades normalmente consumidos em evento
esportivo oficial (Lei nº 11.488, de 2007, art. 38, inciso II).
(Redação dada pelo Decreto nº 7.044, de 2009).

Parágrafo único. A isenção de que trata o caput somente será
concedida se satisfeitos os termos, limites e condições
estabelecidos nos arts. 183 a 185, no que couberem (Lei nº
11.488, de 2007, art. 38, caput). (Redação dada pelo Decreto
nº 7.044, de 2009).