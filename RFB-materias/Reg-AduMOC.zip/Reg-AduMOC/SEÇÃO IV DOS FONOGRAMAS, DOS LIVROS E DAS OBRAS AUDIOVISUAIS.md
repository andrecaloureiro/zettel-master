[[Reg-AduMOC/CAPÍTULO III DOS CASOS ESPECIAIS]]

# SEÇÃO IV DOS FONOGRAMAS, DOS LIVROS E DAS OBRAS AUDIOVISUAIS

Art. 609. Os fonogramas, os livros e as obras audiovisuais,
importados ou a exportar, deverão conter selos ou sinais de
identificação, emitidos e fornecidos na forma da legislação
específica, para atestar o cumprimento das normas legais
referentes ao direito autoral (Lei no 9.610, de 19 de fevereiro
de 1998, art. 113).

Art. 610. Aplica-se, no que couber, às importações ou às
exportações de mercadorias onde haja indício de violação ao
direito autoral, o disposto nos arts. 606 a 608 (Acordo sobre
Aspectos dos Direitos de Propriedade Intelectual
Relacionados ao Comércio, Artigos 51, 52, 53, parágrafo 1, e
55, aprovado pelo Decreto Legislativo no 30, de 1994, e
promulgado pelo Decreto nº 1.355, de 1994).