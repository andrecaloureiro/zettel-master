[[Reg-AduMOC/CAPÍTULO VII DA SUSPENSÃO DO PAGAMENTO]]

# SEÇÃO XI DA NAVEGAÇÃO DE CABOTAGEM E DE APOIO PORTUÁRIO E MARÍTIMO

Art. 292. Será efetuada com suspensão do pagamento da
Contribuição para o PIS/PASEP-Importação e da COFINS-
Importação, nos termos e condições fixados pela Secretaria
da Receita Federal do Brasil, a importação de (Lei nº 11.774,
de 2008, art. 2º, caput):

(Pós-Edital)    884

I - óleo combustível, tipo bunker, MF - Marine Fuel,
classificado no código 2710.19.22 da Nomenclatura Comum
do Mercosul;

II - óleo combustível, tipo bunker, MGO - Marine Gás Oil,
classificado no código 2710.19.21 da Nomenclatura Comum
do Mercosul; e

III - óleo combustível, tipo bunker, ODM - Óleo Diesel
Marítimo, classificado no código 2710.19.21 da
Nomenclatura Comum do Mercosul.

§ 1º A suspensão referida no caput somente se aplica
quando os produtos forem importados por pessoa jurídica
previamente habilitada e destinados à navegação de
cabotagem e de apoio portuário e marítimo (Lei nº 11.774,
de 2008, art. 2º, caput).

§ 2º A pessoa jurídica que não destinar os produtos referidos
no caput à navegação de cabotagem ou de apoio portuário e
marítimo fica obrigada a recolher as contribuições não
pagas, acrescidas de juros e multa de mora, na forma da lei,
contados da data do registro da declaração de importação
(Lei nº 11.774, de 2008, art. 2º, § 1º).

§ 3º Na hipótese de não ser efetuado o recolhimento na
forma do § 2º, caberá lançamento de ofício, com aplicação
de juros e da multa de que trata o art. 725 (Lei nº 11.774, de
2008, art. 2º, § 2º).