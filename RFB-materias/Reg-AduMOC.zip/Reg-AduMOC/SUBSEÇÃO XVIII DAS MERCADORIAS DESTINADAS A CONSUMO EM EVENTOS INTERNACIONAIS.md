[[Reg-AduMOC/SEÇÃO VI DOS TERMOS, LIMITES E CONDIÇÕES]]

# SUBSEÇÃO XVIII DAS MERCADORIAS DESTINADAS A CONSUMO EM EVENTOS INTERNACIONAIS

Art. 179. A isenção do imposto na importação de
mercadorias destinadas a consumo em eventos
internacionais somente será reconhecida se o consumo
ocorrer no recinto de congressos, feiras e exposições
internacionais e eventos assemelhados, a título de

(Pós-Edital)    864

promoção ou degustação, de montagem ou conservação de
estandes, ou de demonstração de equipamentos em
exposição (Lei no 8.383, de 1991, art. 70).

§ 1º A isenção não se aplica a mercadorias destinadas à
montagem de estandes, suscetíveis de serem aproveitadas
após o evento (Lei nº 8.383, de 1991, art. 70, § 1º).

§ 2º É condição para gozo da isenção que nenhum
pagamento, a qualquer título, seja efetuado ao exterior, em
relação às mercadorias mencionadas no caput (Lei nº 8.383,
de 1991, art. 70, § 2º).

§ 3º A importação das mercadorias objeto da isenção está
dispensada de licenciamento, e sujeita à regulamentação
editada pelo Ministério da Fazenda (Lei nº 8.383, de 1991,
art. 70, § 3º).