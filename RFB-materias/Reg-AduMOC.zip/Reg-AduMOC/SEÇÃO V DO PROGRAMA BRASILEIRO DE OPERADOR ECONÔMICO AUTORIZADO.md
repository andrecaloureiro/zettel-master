[[Reg-AduMOC/CAPÍTULO III DAS ATIVIDADES RELACIONADAS AOS SERVIÇOS ADUANEIROS]]

# SEÇÃO V DO PROGRAMA BRASILEIRO DE OPERADOR ECONÔMICO AUTORIZADO

(Incluído pelo Decreto nº 10.550, de 2020).

Art. 814-A. Os intervenientes nas operações de comércio
exterior que satisfaçam critérios relacionados à segurança da
cadeia logística ou ao histórico de cumprimento da legislação
aduaneira, dentre outros, poderão requerer a certificação do
Programa Brasileiro de Operador Econômico Autorizado -
Programa OEA. (Incluído pelo Decreto nº 10.550, de 2020).

§ 1º O Programa OEA consiste na concessão de medidas de
facilitação de comércio exterior específicas para os
intervenientes nele certificados. (Incluído pelo Decreto nº
10.550, de 2020).

§ 2º A certificação a que se refere o caput será concedida em
caráter precário e a sua manutenção estará vinculada ao
cumprimento dos requisitos e critérios estabelecidos em
legislação específica. (Incluído pelo Decreto nº 10.550, de
2020).

§ 3º A Secretaria Especial da Receita Federal do Brasil do
Ministério da Economia poderá, no âmbito de suas
competências, editar atos normativos para disciplinar o
disposto neste artigo e estender as medidas a que se refere
o § 1º a procedimentos disciplinados por órgãos ou
entidades anuentes, por meio de ato normativo conjunto.
(Incluído pelo Decreto nº 10.550, de 2020).