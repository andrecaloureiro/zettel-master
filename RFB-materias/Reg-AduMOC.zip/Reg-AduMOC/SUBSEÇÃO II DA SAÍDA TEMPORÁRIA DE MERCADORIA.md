[[Reg-AduMOC/SEÇÃO III DAS NORMAS ESPECÍFICAS]]

# SUBSEÇÃO II DA SAÍDA TEMPORÁRIA DE MERCADORIA

Art. 517. Poderá ser autorizada a saída temporária de
mercadoria, inclusive de veículo, ingressados na Zona Franca
de Manaus com os benefícios fiscais previstos na legislação
específica, para outros pontos do território aduaneiro, com
suspensão do pagamento dos tributos incidentes na
internação, observados os termos, prazos e condições
estabelecidos em ato normativo da Secretaria da Receita
Federal do Brasil.