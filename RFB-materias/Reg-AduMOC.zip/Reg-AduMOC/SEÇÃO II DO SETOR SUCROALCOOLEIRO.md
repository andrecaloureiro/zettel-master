[[Reg-AduMOC/CAPÍTULO V DAS ISENÇÕES DO IMPOSTO]]

# SEÇÃO II DO SETOR SUCROALCOOLEIRO

Art. 219. As usinas produtoras de açúcar que não possuam
destilarias anexas poderão exportar os seus excedentes,
desde que comprovem sua participação no mercado interno,
conforme estabelecido nos planos anuais de safra (Lei nº
9.362, de 13 de dezembro de 1996, art. 1º, § 7º).

Art. 220. Aos excedentes de que trata o art. 219 e aos de mel
rico e de mel residual poderá ser concedida isenção total ou
parcial do imposto, mediante despacho fundamentado
conjunto dos Ministros de Estado da Fazenda e do
Desenvolvimento, Indústria e Comércio Exterior, que fixará,
dentre outros requisitos, o prazo de sua duração (Lei nº
9.362, de 1996, art. 3º).

Art. 221. Em operações de exportação de açúcar, álcool, mel
rico e mel residual, com isenção total ou parcial do imposto,
a emissão de registro de venda e de registro de exportação
ou documento de efeito equivalente, pela Secretaria de
Comércio Exterior, sujeita-se aos estritos termos do
despacho referido no art. 220 (Lei no 9.362, de 1996, art. 4º).

Art. 222. A exportação de açúcar, álcool, mel rico e mel
residual, com a isenção de que trata o art. 220, será objeto
de cotas distribuídas às unidades industriais e às refinarias
autônomas exportadoras nos planos anuais de safra (Lei nº
9.362, de 1996, art. 5º)

Art. 223. A isenção total ou parcial do imposto não gera
direito adquirido, e será tornada insubsistente sempre que
se apure que o habilitado não satisfazia ou deixou de
satisfazer os requisitos, ou não cumpria ou deixou de
cumprir as condições para a concessão do benefício (Lei nº
9.362, de 1996, art. 6º).