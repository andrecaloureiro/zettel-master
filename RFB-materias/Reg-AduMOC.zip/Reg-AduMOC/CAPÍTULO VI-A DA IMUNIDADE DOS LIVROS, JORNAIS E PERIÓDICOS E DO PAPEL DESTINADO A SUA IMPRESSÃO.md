[[Reg-AduMOC/TÍTULO I DO IMPOSTO SOBRE PRODUTOS INDUSTRIALIZADOS]]

# CAPÍTULO VI-A DA IMUNIDADE DOS LIVROS, JORNAIS E PERIÓDICOS E DO PAPEL DESTINADO A SUA IMPRESSÃO

(Incluído pelo Decreto nº 7.213, de 2010).

Art. 245-A. São imunes do imposto as importações de livros,
jornais e periódicos e do papel destinado a sua impressão,
observado o disposto no art. 211-B (Constituição, art. 150,
inciso VI, alínea "d"; e Lei nº 11.945, de 2009, art. 1º).
(Incluído pelo Decreto nº 7.213, de 2010).