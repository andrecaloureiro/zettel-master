[[Reg-AduMOC/TÍTULO III DA CONTRIBUIÇÃO PARA O PISPASEP E DA COFINS, NA IMPORTAÇÃO DE CIGARRO]]

# CAPÍTULO III DAS DISPOSIÇÕES FINAIS

Art. 296. Aplicam-se à pessoa jurídica adquirente de
mercadoria de procedência estrangeira, no caso da
importação realizada por sua conta e ordem, por intermédio
de pessoa jurídica importadora, as normas de incidência da
contribuição para o PIS/PASEP e da COFINS, sobre a receita
bruta do importador (Medida Provisória nº 2.158-35, de
2001, art. 81).

Parágrafo único. Para fins de aplicação do disposto no caput,
presume-se por conta e ordem de terceiro a operação de
comércio exterior realizada mediante utilização de recursos
deste, ou em desacordo com os requisitos e condições
estabelecidos na forma da alínea "b" do inciso I do § 1º do
art. 106 (Lei no 10.637, de 2002, art. 27; e Lei nº 11.281, de
2006, art. 11, § 2º).

Art. 296-A. Aplica-se às contribuições de que trata este Título
o disposto no art. 258-A (Lei no 11.945, de 2009, art. 22).
(Incluído pelo Decreto nº 7.213, de 2010).

Art. 297. O disposto neste Título não prejudica a exigência
das contribuições de que trata o Título II.