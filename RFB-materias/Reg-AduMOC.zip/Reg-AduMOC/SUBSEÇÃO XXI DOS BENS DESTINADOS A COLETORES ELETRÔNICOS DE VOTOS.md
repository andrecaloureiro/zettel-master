[[Reg-AduMOC/SEÇÃO VI DOS TERMOS, LIMITES E CONDIÇÕES]]

# SUBSEÇÃO XXI DOS BENS DESTINADOS A COLETORES ELETRÔNICOS DE VOTOS

Art. 182. A isenção do imposto na importação de bens
destinados a coletores eletrônicos de votos aplica-se (Lei nº
9.643, de 1998, art. 1º):

I - às matérias-primas e aos produtos intermediários que se
destinem à industrialização, no País, de coletores eletrônicos
de votos, a serem diretamente fornecidos ao Tribunal
Superior Eleitoral; e

II - aos produtos classificados nos códigos 8471.60.52,
8471.60.61, 8473.30.49, 8504.40.21 e 8534.00.00, da
Nomenclatura Comum do Mercosul, destinados aos
coletores eletrônicos de votos.
 
Parágrafo único. Para o reconhecimento da isenção, a
empresa beneficiária deverá apresentar à Secretaria da
Receita Federal do Brasil relação quantitativa dos bens a
serem importados, aprovada pelo Ministério da Ciência e
Tecnologia (Lei nº 9.643, de 1998, art. 2º).