[[Reg-AduMOC/TÍTULO I DOS REGIMES ADUANEIROS ESPECIAIS]]

# CAPÍTULO III DA ADMISSÃO TEMPORÁRIA

Art. 353. O regime aduaneiro especial de admissão
temporária é o que permite a importação de bens que
devam permanecer no País durante prazo fixado, com
suspensão total do pagamento de tributos, ou com
suspensão parcial, no caso de utilização econômica, na
forma e nas condições deste Capítulo (Decreto-Lei no 37, de
1966, art. 75; e Lei no 9.430, de 1996, art. 79, caput).

##[[Reg-AduMOC/SEÇÃO I DA ADMISSÃO TEMPORÁRIA COM SUSPENSÃO TOTAL DO PAGAMENTO DE TRIBUTOS]]

##[[Reg-AduMOC/SEÇÃO II DA ADMISSÃO TEMPORÁRIA PARA UTILIZAÇÃO ECONÔMICA]]

##[[Reg-AduMOC/SEÇÃO III DAS DISPOSIÇÕES FINAIS]]