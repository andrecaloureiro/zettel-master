[[Reg-AduMOC/SEÇÃO VI DOS TERMOS, LIMITES E CONDIÇÕES]]

# SUBSEÇÃO VII DAS REMESSAS POSTAIS E DAS ENCOMENDAS AÉREAS INTERNACIONAIS, DESTINADAS A PESSOA FÍSICA

Art. 154. A isenção para remessas postais internacionais
destinadas a pessoa física aplica-se aos bens nelas contidos,

(Pós-Edital)    860

cujo valor não exceda o limite estabelecido pelo Ministro de
Estado da Fazenda, desde que não se prestem à utilização
com fins lucrativos (Decreto-Lei nº 1.804, de 1980, art. 2º,
inciso II, com a redação dada pela Lei nº 8.383, de 1991, art.
93).

§ 1º O limite a que se refere o caput não poderá ser superior
a U$ 100,00 (cem dólares dos Estados Unidos da América),
ou o equivalente em outra moeda (Decreto-Lei nº 1.804, de
1980, art. 2º, inciso II, com a redação dada pela Lei nº 8.383,
de 1991, art. 93).

§ 2º A isenção para encomendas aéreas internacionais, nas
condições referidas no caput, será aplicada em
conformidade com a regulamentação editada pelo
Ministério da Fazenda (Decreto-Lei nº 1.804, de 1980, art. 2º,
parágrafo único).