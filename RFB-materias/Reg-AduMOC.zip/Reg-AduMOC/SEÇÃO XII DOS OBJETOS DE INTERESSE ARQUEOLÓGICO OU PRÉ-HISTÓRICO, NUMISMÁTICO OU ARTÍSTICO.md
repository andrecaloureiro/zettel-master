[[Reg-AduMOC/CAPÍTULO III DOS CASOS ESPECIAIS]]

# SEÇÃO XII DOS OBJETOS DE INTERESSE ARQUEOLÓGICO OU PRÉ-HISTÓRICO, NUMISMÁTICO OU ARTÍSTICO

Art. 626. Nenhum objeto que apresente interesse
arqueológico ou pré-histórico, numismático ou artístico
poderá ser transferido para o exterior, sem licença expressa
do Instituto do Patrimônio Histórico e Artístico Nacional (Lei
no 3.924, de 26 de julho de 1961, art. 20).

(Pós-Edital)    929

Art. 627. A inobservância do previsto no art. 626 implicará
apreensão sumária do objeto a ser transferido, sem prejuízo
das demais penalidades a que estiver sujeito o responsável
(Lei nº 3.924, de 1961, art. 21, caput).

Parágrafo único. O objeto apreendido, de que trata o caput,
será entregue ao Instituto do Patrimônio Histórico e Artístico
Nacional (Lei nº 3.924, de 1961, art. 21, parágrafo único).